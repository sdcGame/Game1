gdjs.Level0Code = {};
gdjs.Level0Code.GDBaground1Objects1= [];
gdjs.Level0Code.GDBaground1Objects2= [];
gdjs.Level0Code.GDBaground1Objects3= [];
gdjs.Level0Code.GDBuy1Objects1= [];
gdjs.Level0Code.GDBuy1Objects2= [];
gdjs.Level0Code.GDBuy1Objects3= [];
gdjs.Level0Code.GDBorder1Objects1= [];
gdjs.Level0Code.GDBorder1Objects2= [];
gdjs.Level0Code.GDBorder1Objects3= [];
gdjs.Level0Code.GDTUObjects1= [];
gdjs.Level0Code.GDTUObjects2= [];
gdjs.Level0Code.GDTUObjects3= [];
gdjs.Level0Code.GDADesignersObjects1= [];
gdjs.Level0Code.GDADesignersObjects2= [];
gdjs.Level0Code.GDADesignersObjects3= [];
gdjs.Level0Code.GDMenumenuObjects1= [];
gdjs.Level0Code.GDMenumenuObjects2= [];
gdjs.Level0Code.GDMenumenuObjects3= [];
gdjs.Level0Code.GDHands1Objects1= [];
gdjs.Level0Code.GDHands1Objects2= [];
gdjs.Level0Code.GDHands1Objects3= [];
gdjs.Level0Code.GDBoyAd1Objects1= [];
gdjs.Level0Code.GDBoyAd1Objects2= [];
gdjs.Level0Code.GDBoyAd1Objects3= [];
gdjs.Level0Code.GDGirlAD1Objects1= [];
gdjs.Level0Code.GDGirlAD1Objects2= [];
gdjs.Level0Code.GDGirlAD1Objects3= [];
gdjs.Level0Code.GDGreen1Objects1= [];
gdjs.Level0Code.GDGreen1Objects2= [];
gdjs.Level0Code.GDGreen1Objects3= [];
gdjs.Level0Code.GDSky1Objects1= [];
gdjs.Level0Code.GDSky1Objects2= [];
gdjs.Level0Code.GDSky1Objects3= [];
gdjs.Level0Code.GDDonate1Objects1= [];
gdjs.Level0Code.GDDonate1Objects2= [];
gdjs.Level0Code.GDDonate1Objects3= [];
gdjs.Level0Code.GDUPIidObjects1= [];
gdjs.Level0Code.GDUPIidObjects2= [];
gdjs.Level0Code.GDUPIidObjects3= [];

gdjs.Level0Code.conditionTrue_0 = {val:false};
gdjs.Level0Code.condition0IsTrue_0 = {val:false};
gdjs.Level0Code.condition1IsTrue_0 = {val:false};
gdjs.Level0Code.conditionTrue_1 = {val:false};
gdjs.Level0Code.condition0IsTrue_1 = {val:false};
gdjs.Level0Code.condition1IsTrue_1 = {val:false};


gdjs.Level0Code.eventsList0 = function(runtimeScene) {

};gdjs.Level0Code.eventsList1 = function(runtimeScene) {

};gdjs.Level0Code.mapOfGDgdjs_46Level0Code_46GDMenumenuObjects1Objects = Hashtable.newFrom({"Menumenu": gdjs.Level0Code.GDMenumenuObjects1});
gdjs.Level0Code.mapOfGDgdjs_46Level0Code_46GDMenumenuObjects1Objects = Hashtable.newFrom({"Menumenu": gdjs.Level0Code.GDMenumenuObjects1});
gdjs.Level0Code.eventsList2 = function(runtimeScene) {

{


gdjs.Level0Code.condition0IsTrue_0.val = false;
{
{gdjs.Level0Code.conditionTrue_1 = gdjs.Level0Code.condition0IsTrue_0;
gdjs.Level0Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16084284);
}
}if (gdjs.Level0Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.Level0Code.eventsList3 = function(runtimeScene) {

{


gdjs.Level0Code.condition0IsTrue_0.val = false;
{
gdjs.Level0Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level0Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level0Code.GDMenumenuObjects1, gdjs.Level0Code.GDMenumenuObjects2);

{for(var i = 0, len = gdjs.Level0Code.GDMenumenuObjects2.length ;i < len;++i) {
    gdjs.Level0Code.GDMenumenuObjects2[i].setAnimationName("StartPressed");
}
}
{ //Subevents
gdjs.Level0Code.eventsList2(runtimeScene);} //End of subevents
}

}


{


gdjs.Level0Code.condition0IsTrue_0.val = false;
{
gdjs.Level0Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Level0Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}{gdjs.adMob.showRewardedVideo();
}}

}


};gdjs.Level0Code.eventsList4 = function(runtimeScene) {

{


gdjs.Level0Code.eventsList0(runtimeScene);
}


{


gdjs.Level0Code.condition0IsTrue_0.val = false;
{
gdjs.Level0Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level0Code.condition0IsTrue_0.val) {
{gdjs.adMob.setupBanner("ca-app-pub-7829362827039995~7807956182", "", true);
}{gdjs.adMob.loadInterstitial("ca-app-pub-7829362827039995/8454274703", "", false);
}{gdjs.adMob.loadRewardedVideo("ca-app-pub-7829362827039995/9575784689", "", false);
}}

}


{


{
{gdjs.adMob.showBanner();
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.Level0Code.eventsList1(runtimeScene);
}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Menumenu"), gdjs.Level0Code.GDMenumenuObjects1);

gdjs.Level0Code.condition0IsTrue_0.val = false;
{
gdjs.Level0Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level0Code.mapOfGDgdjs_46Level0Code_46GDMenumenuObjects1Objects, runtimeScene, true, true);
}if (gdjs.Level0Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level0Code.GDMenumenuObjects1 */
{for(var i = 0, len = gdjs.Level0Code.GDMenumenuObjects1.length ;i < len;++i) {
    gdjs.Level0Code.GDMenumenuObjects1[i].setAnimationName("StartNormal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Menumenu"), gdjs.Level0Code.GDMenumenuObjects1);

gdjs.Level0Code.condition0IsTrue_0.val = false;
{
gdjs.Level0Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level0Code.mapOfGDgdjs_46Level0Code_46GDMenumenuObjects1Objects, runtimeScene, true, false);
}if (gdjs.Level0Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level0Code.GDMenumenuObjects1 */
{for(var i = 0, len = gdjs.Level0Code.GDMenumenuObjects1.length ;i < len;++i) {
    gdjs.Level0Code.GDMenumenuObjects1[i].setAnimationName("StartHover");
}
}
{ //Subevents
gdjs.Level0Code.eventsList3(runtimeScene);} //End of subevents
}

}


{


{
}

}


{


{
}

}


};

gdjs.Level0Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level0Code.GDBaground1Objects1.length = 0;
gdjs.Level0Code.GDBaground1Objects2.length = 0;
gdjs.Level0Code.GDBaground1Objects3.length = 0;
gdjs.Level0Code.GDBuy1Objects1.length = 0;
gdjs.Level0Code.GDBuy1Objects2.length = 0;
gdjs.Level0Code.GDBuy1Objects3.length = 0;
gdjs.Level0Code.GDBorder1Objects1.length = 0;
gdjs.Level0Code.GDBorder1Objects2.length = 0;
gdjs.Level0Code.GDBorder1Objects3.length = 0;
gdjs.Level0Code.GDTUObjects1.length = 0;
gdjs.Level0Code.GDTUObjects2.length = 0;
gdjs.Level0Code.GDTUObjects3.length = 0;
gdjs.Level0Code.GDADesignersObjects1.length = 0;
gdjs.Level0Code.GDADesignersObjects2.length = 0;
gdjs.Level0Code.GDADesignersObjects3.length = 0;
gdjs.Level0Code.GDMenumenuObjects1.length = 0;
gdjs.Level0Code.GDMenumenuObjects2.length = 0;
gdjs.Level0Code.GDMenumenuObjects3.length = 0;
gdjs.Level0Code.GDHands1Objects1.length = 0;
gdjs.Level0Code.GDHands1Objects2.length = 0;
gdjs.Level0Code.GDHands1Objects3.length = 0;
gdjs.Level0Code.GDBoyAd1Objects1.length = 0;
gdjs.Level0Code.GDBoyAd1Objects2.length = 0;
gdjs.Level0Code.GDBoyAd1Objects3.length = 0;
gdjs.Level0Code.GDGirlAD1Objects1.length = 0;
gdjs.Level0Code.GDGirlAD1Objects2.length = 0;
gdjs.Level0Code.GDGirlAD1Objects3.length = 0;
gdjs.Level0Code.GDGreen1Objects1.length = 0;
gdjs.Level0Code.GDGreen1Objects2.length = 0;
gdjs.Level0Code.GDGreen1Objects3.length = 0;
gdjs.Level0Code.GDSky1Objects1.length = 0;
gdjs.Level0Code.GDSky1Objects2.length = 0;
gdjs.Level0Code.GDSky1Objects3.length = 0;
gdjs.Level0Code.GDDonate1Objects1.length = 0;
gdjs.Level0Code.GDDonate1Objects2.length = 0;
gdjs.Level0Code.GDDonate1Objects3.length = 0;
gdjs.Level0Code.GDUPIidObjects1.length = 0;
gdjs.Level0Code.GDUPIidObjects2.length = 0;
gdjs.Level0Code.GDUPIidObjects3.length = 0;

gdjs.Level0Code.eventsList4(runtimeScene);

return;

}

gdjs['Level0Code'] = gdjs.Level0Code;
