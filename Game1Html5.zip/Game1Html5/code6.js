gdjs.Pause_95screenCode = {};
gdjs.Pause_95screenCode.GDPlayObjects1= [];
gdjs.Pause_95screenCode.GDPlayObjects2= [];
gdjs.Pause_95screenCode.GDPlayObjects3= [];
gdjs.Pause_95screenCode.GDSky1Objects1= [];
gdjs.Pause_95screenCode.GDSky1Objects2= [];
gdjs.Pause_95screenCode.GDSky1Objects3= [];
gdjs.Pause_95screenCode.GDBorder1Objects1= [];
gdjs.Pause_95screenCode.GDBorder1Objects2= [];
gdjs.Pause_95screenCode.GDBorder1Objects3= [];
gdjs.Pause_95screenCode.GDInfo1Objects1= [];
gdjs.Pause_95screenCode.GDInfo1Objects2= [];
gdjs.Pause_95screenCode.GDInfo1Objects3= [];
gdjs.Pause_95screenCode.GDButtonMainMenuObjects1= [];
gdjs.Pause_95screenCode.GDButtonMainMenuObjects2= [];
gdjs.Pause_95screenCode.GDButtonMainMenuObjects3= [];
gdjs.Pause_95screenCode.GDNewTextObjects1= [];
gdjs.Pause_95screenCode.GDNewTextObjects2= [];
gdjs.Pause_95screenCode.GDNewTextObjects3= [];
gdjs.Pause_95screenCode.GDBoardObjects1= [];
gdjs.Pause_95screenCode.GDBoardObjects2= [];
gdjs.Pause_95screenCode.GDBoardObjects3= [];
gdjs.Pause_95screenCode.GDpptcObjects1= [];
gdjs.Pause_95screenCode.GDpptcObjects2= [];
gdjs.Pause_95screenCode.GDpptcObjects3= [];
gdjs.Pause_95screenCode.GDNoteObjects1= [];
gdjs.Pause_95screenCode.GDNoteObjects2= [];
gdjs.Pause_95screenCode.GDNoteObjects3= [];
gdjs.Pause_95screenCode.GDAttention1Objects1= [];
gdjs.Pause_95screenCode.GDAttention1Objects2= [];
gdjs.Pause_95screenCode.GDAttention1Objects3= [];
gdjs.Pause_95screenCode.GDDonate1Objects1= [];
gdjs.Pause_95screenCode.GDDonate1Objects2= [];
gdjs.Pause_95screenCode.GDDonate1Objects3= [];
gdjs.Pause_95screenCode.GDUPIidObjects1= [];
gdjs.Pause_95screenCode.GDUPIidObjects2= [];
gdjs.Pause_95screenCode.GDUPIidObjects3= [];
gdjs.Pause_95screenCode.GDBuy1Objects1= [];
gdjs.Pause_95screenCode.GDBuy1Objects2= [];
gdjs.Pause_95screenCode.GDBuy1Objects3= [];
gdjs.Pause_95screenCode.GDHands1Objects1= [];
gdjs.Pause_95screenCode.GDHands1Objects2= [];
gdjs.Pause_95screenCode.GDHands1Objects3= [];
gdjs.Pause_95screenCode.GDGmailObjects1= [];
gdjs.Pause_95screenCode.GDGmailObjects2= [];
gdjs.Pause_95screenCode.GDGmailObjects3= [];

gdjs.Pause_95screenCode.conditionTrue_0 = {val:false};
gdjs.Pause_95screenCode.condition0IsTrue_0 = {val:false};
gdjs.Pause_95screenCode.condition1IsTrue_0 = {val:false};
gdjs.Pause_95screenCode.conditionTrue_1 = {val:false};
gdjs.Pause_95screenCode.condition0IsTrue_1 = {val:false};
gdjs.Pause_95screenCode.condition1IsTrue_1 = {val:false};


gdjs.Pause_95screenCode.eventsList0 = function(runtimeScene) {

};gdjs.Pause_95screenCode.eventsList1 = function(runtimeScene) {

};gdjs.Pause_95screenCode.mapOfGDgdjs_46Pause_9595screenCode_46GDPlayObjects1Objects = Hashtable.newFrom({"Play": gdjs.Pause_95screenCode.GDPlayObjects1});
gdjs.Pause_95screenCode.mapOfGDgdjs_46Pause_9595screenCode_46GDPlayObjects1Objects = Hashtable.newFrom({"Play": gdjs.Pause_95screenCode.GDPlayObjects1});
gdjs.Pause_95screenCode.eventsList2 = function(runtimeScene) {

{


gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
{gdjs.Pause_95screenCode.conditionTrue_1 = gdjs.Pause_95screenCode.condition0IsTrue_0;
gdjs.Pause_95screenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16479484);
}
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.Pause_95screenCode.eventsList3 = function(runtimeScene) {

{


gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
gdjs.Pause_95screenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Pause_95screenCode.GDPlayObjects1, gdjs.Pause_95screenCode.GDPlayObjects2);

{for(var i = 0, len = gdjs.Pause_95screenCode.GDPlayObjects2.length ;i < len;++i) {
    gdjs.Pause_95screenCode.GDPlayObjects2[i].setAnimationName("StartPressed");
}
}
{ //Subevents
gdjs.Pause_95screenCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
gdjs.Pause_95screenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


};gdjs.Pause_95screenCode.eventsList4 = function(runtimeScene) {

};gdjs.Pause_95screenCode.mapOfGDgdjs_46Pause_9595screenCode_46GDButtonMainMenuObjects1Objects = Hashtable.newFrom({"ButtonMainMenu": gdjs.Pause_95screenCode.GDButtonMainMenuObjects1});
gdjs.Pause_95screenCode.mapOfGDgdjs_46Pause_9595screenCode_46GDButtonMainMenuObjects1Objects = Hashtable.newFrom({"ButtonMainMenu": gdjs.Pause_95screenCode.GDButtonMainMenuObjects1});
gdjs.Pause_95screenCode.eventsList5 = function(runtimeScene) {

{


gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
{gdjs.Pause_95screenCode.conditionTrue_1 = gdjs.Pause_95screenCode.condition0IsTrue_0;
gdjs.Pause_95screenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16483020);
}
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.Pause_95screenCode.eventsList6 = function(runtimeScene) {

{


gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
gdjs.Pause_95screenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Pause_95screenCode.GDButtonMainMenuObjects1, gdjs.Pause_95screenCode.GDButtonMainMenuObjects2);

{for(var i = 0, len = gdjs.Pause_95screenCode.GDButtonMainMenuObjects2.length ;i < len;++i) {
    gdjs.Pause_95screenCode.GDButtonMainMenuObjects2[i].setAnimationName("MainMenuPressed");
}
}
{ //Subevents
gdjs.Pause_95screenCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
gdjs.Pause_95screenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}{gdjs.adMob.showRewardedVideo();
}}

}


};gdjs.Pause_95screenCode.eventsList7 = function(runtimeScene) {

};gdjs.Pause_95screenCode.mapOfGDgdjs_46Pause_9595screenCode_46GDpptcObjects1Objects = Hashtable.newFrom({"pptc": gdjs.Pause_95screenCode.GDpptcObjects1});
gdjs.Pause_95screenCode.mapOfGDgdjs_46Pause_9595screenCode_46GDpptcObjects1Objects = Hashtable.newFrom({"pptc": gdjs.Pause_95screenCode.GDpptcObjects1});
gdjs.Pause_95screenCode.eventsList8 = function(runtimeScene) {

{


gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
{gdjs.Pause_95screenCode.conditionTrue_1 = gdjs.Pause_95screenCode.condition0IsTrue_0;
gdjs.Pause_95screenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16486524);
}
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.Pause_95screenCode.eventsList9 = function(runtimeScene) {

{


gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
gdjs.Pause_95screenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Pause_95screenCode.GDpptcObjects1 */
{for(var i = 0, len = gdjs.Pause_95screenCode.GDpptcObjects1.length ;i < len;++i) {
    gdjs.Pause_95screenCode.GDpptcObjects1[i].setAnimationName("StartPressed");
}
}{gdjs.evtTools.window.openURL("https://sdcreations1.blogspot.com/2023/01/a1gamesprivacy-policyterms-conditions.html", runtimeScene);
}
{ //Subevents
gdjs.Pause_95screenCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.Pause_95screenCode.eventsList10 = function(runtimeScene) {

};gdjs.Pause_95screenCode.mapOfGDgdjs_46Pause_9595screenCode_46GDNoteObjects1Objects = Hashtable.newFrom({"Note": gdjs.Pause_95screenCode.GDNoteObjects1});
gdjs.Pause_95screenCode.mapOfGDgdjs_46Pause_9595screenCode_46GDNoteObjects1Objects = Hashtable.newFrom({"Note": gdjs.Pause_95screenCode.GDNoteObjects1});
gdjs.Pause_95screenCode.eventsList11 = function(runtimeScene) {

{


gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
{gdjs.Pause_95screenCode.conditionTrue_1 = gdjs.Pause_95screenCode.condition0IsTrue_0;
gdjs.Pause_95screenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16490076);
}
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.Pause_95screenCode.eventsList12 = function(runtimeScene) {

{


gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
gdjs.Pause_95screenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Attention1"), gdjs.Pause_95screenCode.GDAttention1Objects2);
gdjs.copyArray(gdjs.Pause_95screenCode.GDNoteObjects1, gdjs.Pause_95screenCode.GDNoteObjects2);

{for(var i = 0, len = gdjs.Pause_95screenCode.GDNoteObjects2.length ;i < len;++i) {
    gdjs.Pause_95screenCode.GDNoteObjects2[i].setAnimationName("StartPressed");
}
}{for(var i = 0, len = gdjs.Pause_95screenCode.GDAttention1Objects2.length ;i < len;++i) {
    gdjs.Pause_95screenCode.GDAttention1Objects2[i].setAnimationName("Play");
}
}
{ //Subevents
gdjs.Pause_95screenCode.eventsList11(runtimeScene);} //End of subevents
}

}


{


gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
gdjs.Pause_95screenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Attention1"), gdjs.Pause_95screenCode.GDAttention1Objects1);
{for(var i = 0, len = gdjs.Pause_95screenCode.GDAttention1Objects1.length ;i < len;++i) {
    gdjs.Pause_95screenCode.GDAttention1Objects1[i].setAnimationName("Hide");
}
}}

}


};gdjs.Pause_95screenCode.eventsList13 = function(runtimeScene) {

{


gdjs.Pause_95screenCode.eventsList0(runtimeScene);
}


{


gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
gdjs.Pause_95screenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
{gdjs.adMob.setupBanner("ca-app-pub-7829362827039995~7807956182", "", true);
}{gdjs.adMob.loadInterstitial("ca-app-pub-7829362827039995/8454274703", "", false);
}{gdjs.adMob.loadRewardedVideo("ca-app-pub-7829362827039995/9575784689", "", false);
}}

}


{


{
{gdjs.adMob.showBanner();
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.Pause_95screenCode.eventsList1(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.Pause_95screenCode.GDPlayObjects1);

gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
gdjs.Pause_95screenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Pause_95screenCode.mapOfGDgdjs_46Pause_9595screenCode_46GDPlayObjects1Objects, runtimeScene, true, true);
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Pause_95screenCode.GDPlayObjects1 */
{for(var i = 0, len = gdjs.Pause_95screenCode.GDPlayObjects1.length ;i < len;++i) {
    gdjs.Pause_95screenCode.GDPlayObjects1[i].setAnimationName("StartNormal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.Pause_95screenCode.GDPlayObjects1);

gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
gdjs.Pause_95screenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Pause_95screenCode.mapOfGDgdjs_46Pause_9595screenCode_46GDPlayObjects1Objects, runtimeScene, true, false);
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Pause_95screenCode.GDPlayObjects1 */
{for(var i = 0, len = gdjs.Pause_95screenCode.GDPlayObjects1.length ;i < len;++i) {
    gdjs.Pause_95screenCode.GDPlayObjects1[i].setAnimationName("StartHover");
}
}
{ //Subevents
gdjs.Pause_95screenCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


gdjs.Pause_95screenCode.eventsList4(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("ButtonMainMenu"), gdjs.Pause_95screenCode.GDButtonMainMenuObjects1);

gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
gdjs.Pause_95screenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Pause_95screenCode.mapOfGDgdjs_46Pause_9595screenCode_46GDButtonMainMenuObjects1Objects, runtimeScene, true, true);
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Pause_95screenCode.GDButtonMainMenuObjects1 */
{for(var i = 0, len = gdjs.Pause_95screenCode.GDButtonMainMenuObjects1.length ;i < len;++i) {
    gdjs.Pause_95screenCode.GDButtonMainMenuObjects1[i].setAnimationName("MainMenuNormal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ButtonMainMenu"), gdjs.Pause_95screenCode.GDButtonMainMenuObjects1);

gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
gdjs.Pause_95screenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Pause_95screenCode.mapOfGDgdjs_46Pause_9595screenCode_46GDButtonMainMenuObjects1Objects, runtimeScene, true, false);
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Pause_95screenCode.GDButtonMainMenuObjects1 */
{for(var i = 0, len = gdjs.Pause_95screenCode.GDButtonMainMenuObjects1.length ;i < len;++i) {
    gdjs.Pause_95screenCode.GDButtonMainMenuObjects1[i].setAnimationName("MainMenuHover");
}
}
{ //Subevents
gdjs.Pause_95screenCode.eventsList6(runtimeScene);} //End of subevents
}

}


{


gdjs.Pause_95screenCode.eventsList7(runtimeScene);
}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("pptc"), gdjs.Pause_95screenCode.GDpptcObjects1);

gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
gdjs.Pause_95screenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Pause_95screenCode.mapOfGDgdjs_46Pause_9595screenCode_46GDpptcObjects1Objects, runtimeScene, true, true);
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Pause_95screenCode.GDpptcObjects1 */
{for(var i = 0, len = gdjs.Pause_95screenCode.GDpptcObjects1.length ;i < len;++i) {
    gdjs.Pause_95screenCode.GDpptcObjects1[i].setAnimationName("StartNormal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("pptc"), gdjs.Pause_95screenCode.GDpptcObjects1);

gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
gdjs.Pause_95screenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Pause_95screenCode.mapOfGDgdjs_46Pause_9595screenCode_46GDpptcObjects1Objects, runtimeScene, true, false);
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Pause_95screenCode.GDpptcObjects1 */
{for(var i = 0, len = gdjs.Pause_95screenCode.GDpptcObjects1.length ;i < len;++i) {
    gdjs.Pause_95screenCode.GDpptcObjects1[i].setAnimationName("StartHover");
}
}
{ //Subevents
gdjs.Pause_95screenCode.eventsList9(runtimeScene);} //End of subevents
}

}


{


gdjs.Pause_95screenCode.eventsList10(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Note"), gdjs.Pause_95screenCode.GDNoteObjects1);

gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
gdjs.Pause_95screenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Pause_95screenCode.mapOfGDgdjs_46Pause_9595screenCode_46GDNoteObjects1Objects, runtimeScene, true, true);
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Pause_95screenCode.GDNoteObjects1 */
{for(var i = 0, len = gdjs.Pause_95screenCode.GDNoteObjects1.length ;i < len;++i) {
    gdjs.Pause_95screenCode.GDNoteObjects1[i].setAnimationName("StartNormal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Note"), gdjs.Pause_95screenCode.GDNoteObjects1);

gdjs.Pause_95screenCode.condition0IsTrue_0.val = false;
{
gdjs.Pause_95screenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Pause_95screenCode.mapOfGDgdjs_46Pause_9595screenCode_46GDNoteObjects1Objects, runtimeScene, true, false);
}if (gdjs.Pause_95screenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Pause_95screenCode.GDNoteObjects1 */
{for(var i = 0, len = gdjs.Pause_95screenCode.GDNoteObjects1.length ;i < len;++i) {
    gdjs.Pause_95screenCode.GDNoteObjects1[i].setAnimationName("StartHover");
}
}
{ //Subevents
gdjs.Pause_95screenCode.eventsList12(runtimeScene);} //End of subevents
}

}


{


{
}

}


{


{
}

}


};

gdjs.Pause_95screenCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Pause_95screenCode.GDPlayObjects1.length = 0;
gdjs.Pause_95screenCode.GDPlayObjects2.length = 0;
gdjs.Pause_95screenCode.GDPlayObjects3.length = 0;
gdjs.Pause_95screenCode.GDSky1Objects1.length = 0;
gdjs.Pause_95screenCode.GDSky1Objects2.length = 0;
gdjs.Pause_95screenCode.GDSky1Objects3.length = 0;
gdjs.Pause_95screenCode.GDBorder1Objects1.length = 0;
gdjs.Pause_95screenCode.GDBorder1Objects2.length = 0;
gdjs.Pause_95screenCode.GDBorder1Objects3.length = 0;
gdjs.Pause_95screenCode.GDInfo1Objects1.length = 0;
gdjs.Pause_95screenCode.GDInfo1Objects2.length = 0;
gdjs.Pause_95screenCode.GDInfo1Objects3.length = 0;
gdjs.Pause_95screenCode.GDButtonMainMenuObjects1.length = 0;
gdjs.Pause_95screenCode.GDButtonMainMenuObjects2.length = 0;
gdjs.Pause_95screenCode.GDButtonMainMenuObjects3.length = 0;
gdjs.Pause_95screenCode.GDNewTextObjects1.length = 0;
gdjs.Pause_95screenCode.GDNewTextObjects2.length = 0;
gdjs.Pause_95screenCode.GDNewTextObjects3.length = 0;
gdjs.Pause_95screenCode.GDBoardObjects1.length = 0;
gdjs.Pause_95screenCode.GDBoardObjects2.length = 0;
gdjs.Pause_95screenCode.GDBoardObjects3.length = 0;
gdjs.Pause_95screenCode.GDpptcObjects1.length = 0;
gdjs.Pause_95screenCode.GDpptcObjects2.length = 0;
gdjs.Pause_95screenCode.GDpptcObjects3.length = 0;
gdjs.Pause_95screenCode.GDNoteObjects1.length = 0;
gdjs.Pause_95screenCode.GDNoteObjects2.length = 0;
gdjs.Pause_95screenCode.GDNoteObjects3.length = 0;
gdjs.Pause_95screenCode.GDAttention1Objects1.length = 0;
gdjs.Pause_95screenCode.GDAttention1Objects2.length = 0;
gdjs.Pause_95screenCode.GDAttention1Objects3.length = 0;
gdjs.Pause_95screenCode.GDDonate1Objects1.length = 0;
gdjs.Pause_95screenCode.GDDonate1Objects2.length = 0;
gdjs.Pause_95screenCode.GDDonate1Objects3.length = 0;
gdjs.Pause_95screenCode.GDUPIidObjects1.length = 0;
gdjs.Pause_95screenCode.GDUPIidObjects2.length = 0;
gdjs.Pause_95screenCode.GDUPIidObjects3.length = 0;
gdjs.Pause_95screenCode.GDBuy1Objects1.length = 0;
gdjs.Pause_95screenCode.GDBuy1Objects2.length = 0;
gdjs.Pause_95screenCode.GDBuy1Objects3.length = 0;
gdjs.Pause_95screenCode.GDHands1Objects1.length = 0;
gdjs.Pause_95screenCode.GDHands1Objects2.length = 0;
gdjs.Pause_95screenCode.GDHands1Objects3.length = 0;
gdjs.Pause_95screenCode.GDGmailObjects1.length = 0;
gdjs.Pause_95screenCode.GDGmailObjects2.length = 0;
gdjs.Pause_95screenCode.GDGmailObjects3.length = 0;

gdjs.Pause_95screenCode.eventsList13(runtimeScene);

return;

}

gdjs['Pause_95screenCode'] = gdjs.Pause_95screenCode;
