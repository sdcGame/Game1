gdjs.MainMenuCode = {};
gdjs.MainMenuCode.GDSky1Objects1= [];
gdjs.MainMenuCode.GDSky1Objects2= [];
gdjs.MainMenuCode.GDSky1Objects3= [];
gdjs.MainMenuCode.GDstObjects1= [];
gdjs.MainMenuCode.GDstObjects2= [];
gdjs.MainMenuCode.GDstObjects3= [];
gdjs.MainMenuCode.GDtcObjects1= [];
gdjs.MainMenuCode.GDtcObjects2= [];
gdjs.MainMenuCode.GDtcObjects3= [];
gdjs.MainMenuCode.GDsubscribe1Objects1= [];
gdjs.MainMenuCode.GDsubscribe1Objects2= [];
gdjs.MainMenuCode.GDsubscribe1Objects3= [];
gdjs.MainMenuCode.GDInfoMObjects1= [];
gdjs.MainMenuCode.GDInfoMObjects2= [];
gdjs.MainMenuCode.GDInfoMObjects3= [];
gdjs.MainMenuCode.GDBorder1Objects1= [];
gdjs.MainMenuCode.GDBorder1Objects2= [];
gdjs.MainMenuCode.GDBorder1Objects3= [];
gdjs.MainMenuCode.GDG_95titalObjects1= [];
gdjs.MainMenuCode.GDG_95titalObjects2= [];
gdjs.MainMenuCode.GDG_95titalObjects3= [];
gdjs.MainMenuCode.GDexitObjects1= [];
gdjs.MainMenuCode.GDexitObjects2= [];
gdjs.MainMenuCode.GDexitObjects3= [];
gdjs.MainMenuCode.GDsdcreationsObjects1= [];
gdjs.MainMenuCode.GDsdcreationsObjects2= [];
gdjs.MainMenuCode.GDsdcreationsObjects3= [];
gdjs.MainMenuCode.GDefa1Objects1= [];
gdjs.MainMenuCode.GDefa1Objects2= [];
gdjs.MainMenuCode.GDefa1Objects3= [];
gdjs.MainMenuCode.GDSnakesA_95B1Objects1= [];
gdjs.MainMenuCode.GDSnakesA_95B1Objects2= [];
gdjs.MainMenuCode.GDSnakesA_95B1Objects3= [];
gdjs.MainMenuCode.GDRed_95AB1Objects1= [];
gdjs.MainMenuCode.GDRed_95AB1Objects2= [];
gdjs.MainMenuCode.GDRed_95AB1Objects3= [];
gdjs.MainMenuCode.GDHRunner_95B1Objects1= [];
gdjs.MainMenuCode.GDHRunner_95B1Objects2= [];
gdjs.MainMenuCode.GDHRunner_95B1Objects3= [];
gdjs.MainMenuCode.GDHalicopterA_95B1Objects1= [];
gdjs.MainMenuCode.GDHalicopterA_95B1Objects2= [];
gdjs.MainMenuCode.GDHalicopterA_95B1Objects3= [];
gdjs.MainMenuCode.GDADb1Objects1= [];
gdjs.MainMenuCode.GDADb1Objects2= [];
gdjs.MainMenuCode.GDADb1Objects3= [];
gdjs.MainMenuCode.GDHands1Objects1= [];
gdjs.MainMenuCode.GDHands1Objects2= [];
gdjs.MainMenuCode.GDHands1Objects3= [];

gdjs.MainMenuCode.conditionTrue_0 = {val:false};
gdjs.MainMenuCode.condition0IsTrue_0 = {val:false};
gdjs.MainMenuCode.condition1IsTrue_0 = {val:false};
gdjs.MainMenuCode.conditionTrue_1 = {val:false};
gdjs.MainMenuCode.condition0IsTrue_1 = {val:false};
gdjs.MainMenuCode.condition1IsTrue_1 = {val:false};


gdjs.MainMenuCode.eventsList0 = function(runtimeScene) {

};gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDRed_9595AB1Objects1Objects = Hashtable.newFrom({"Red_AB1": gdjs.MainMenuCode.GDRed_95AB1Objects1});
gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDRed_9595AB1Objects1Objects = Hashtable.newFrom({"Red_AB1": gdjs.MainMenuCode.GDRed_95AB1Objects1});
gdjs.MainMenuCode.eventsList1 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
{gdjs.MainMenuCode.conditionTrue_1 = gdjs.MainMenuCode.condition0IsTrue_0;
gdjs.MainMenuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16029836);
}
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.MainMenuCode.eventsList2 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainMenuCode.GDRed_95AB1Objects1, gdjs.MainMenuCode.GDRed_95AB1Objects2);

{for(var i = 0, len = gdjs.MainMenuCode.GDRed_95AB1Objects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDRed_95AB1Objects2[i].setAnimationName("StartPressed");
}
}
{ //Subevents
gdjs.MainMenuCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level2", false);
}}

}


};gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDHRunner_9595B1Objects1Objects = Hashtable.newFrom({"HRunner_B1": gdjs.MainMenuCode.GDHRunner_95B1Objects1});
gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDHRunner_9595B1Objects1Objects = Hashtable.newFrom({"HRunner_B1": gdjs.MainMenuCode.GDHRunner_95B1Objects1});
gdjs.MainMenuCode.eventsList3 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
{gdjs.MainMenuCode.conditionTrue_1 = gdjs.MainMenuCode.condition0IsTrue_0;
gdjs.MainMenuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16033220);
}
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.MainMenuCode.eventsList4 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainMenuCode.GDHRunner_95B1Objects1, gdjs.MainMenuCode.GDHRunner_95B1Objects2);

{for(var i = 0, len = gdjs.MainMenuCode.GDHRunner_95B1Objects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDHRunner_95B1Objects2[i].setAnimationName("StartPressed");
}
}
{ //Subevents
gdjs.MainMenuCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level3", false);
}}

}


};gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDHalicopterA_9595B1Objects1Objects = Hashtable.newFrom({"HalicopterA_B1": gdjs.MainMenuCode.GDHalicopterA_95B1Objects1});
gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDHalicopterA_9595B1Objects1Objects = Hashtable.newFrom({"HalicopterA_B1": gdjs.MainMenuCode.GDHalicopterA_95B1Objects1});
gdjs.MainMenuCode.eventsList5 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
{gdjs.MainMenuCode.conditionTrue_1 = gdjs.MainMenuCode.condition0IsTrue_0;
gdjs.MainMenuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16036852);
}
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.MainMenuCode.eventsList6 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainMenuCode.GDHalicopterA_95B1Objects1, gdjs.MainMenuCode.GDHalicopterA_95B1Objects2);

{for(var i = 0, len = gdjs.MainMenuCode.GDHalicopterA_95B1Objects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDHalicopterA_95B1Objects2[i].setAnimationName("StartPressed");
}
}
{ //Subevents
gdjs.MainMenuCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level4", false);
}}

}


};gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDSnakesA_9595B1Objects1Objects = Hashtable.newFrom({"SnakesA_B1": gdjs.MainMenuCode.GDSnakesA_95B1Objects1});
gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDSnakesA_9595B1Objects1Objects = Hashtable.newFrom({"SnakesA_B1": gdjs.MainMenuCode.GDSnakesA_95B1Objects1});
gdjs.MainMenuCode.eventsList7 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
{gdjs.MainMenuCode.conditionTrue_1 = gdjs.MainMenuCode.condition0IsTrue_0;
gdjs.MainMenuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16040380);
}
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.MainMenuCode.eventsList8 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainMenuCode.GDSnakesA_95B1Objects1, gdjs.MainMenuCode.GDSnakesA_95B1Objects2);

{for(var i = 0, len = gdjs.MainMenuCode.GDSnakesA_95B1Objects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDSnakesA_95B1Objects2[i].setAnimationName("StartPressed");
}
}
{ //Subevents
gdjs.MainMenuCode.eventsList7(runtimeScene);} //End of subevents
}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level1", false);
}}

}


};gdjs.MainMenuCode.eventsList9 = function(runtimeScene) {

};gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDexitObjects1Objects = Hashtable.newFrom({"exit": gdjs.MainMenuCode.GDexitObjects1});
gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDexitObjects1Objects = Hashtable.newFrom({"exit": gdjs.MainMenuCode.GDexitObjects1});
gdjs.MainMenuCode.eventsList10 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
{gdjs.MainMenuCode.conditionTrue_1 = gdjs.MainMenuCode.condition0IsTrue_0;
gdjs.MainMenuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16044244);
}
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.MainMenuCode.eventsList11 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainMenuCode.GDexitObjects1, gdjs.MainMenuCode.GDexitObjects2);

{for(var i = 0, len = gdjs.MainMenuCode.GDexitObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDexitObjects2[i].setAnimationName("StartPressed");
}
}
{ //Subevents
gdjs.MainMenuCode.eventsList10(runtimeScene);} //End of subevents
}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}{gdjs.adMob.showInterstitial();
}}

}


};gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDADb1Objects1Objects = Hashtable.newFrom({"ADb1": gdjs.MainMenuCode.GDADb1Objects1});
gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDADb1Objects1Objects = Hashtable.newFrom({"ADb1": gdjs.MainMenuCode.GDADb1Objects1});
gdjs.MainMenuCode.eventsList12 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
{gdjs.MainMenuCode.conditionTrue_1 = gdjs.MainMenuCode.condition0IsTrue_0;
gdjs.MainMenuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16048020);
}
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.MainMenuCode.eventsList13 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainMenuCode.GDADb1Objects1, gdjs.MainMenuCode.GDADb1Objects2);

{for(var i = 0, len = gdjs.MainMenuCode.GDADb1Objects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDADb1Objects2[i].setAnimationName("StartPressed");
}
}
{ //Subevents
gdjs.MainMenuCode.eventsList12(runtimeScene);} //End of subevents
}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level0", false);
}{gdjs.adMob.showInterstitial();
}}

}


};gdjs.MainMenuCode.eventsList14 = function(runtimeScene) {

};gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDsubscribe1Objects1Objects = Hashtable.newFrom({"subscribe1": gdjs.MainMenuCode.GDsubscribe1Objects1});
gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDsubscribe1Objects1Objects = Hashtable.newFrom({"subscribe1": gdjs.MainMenuCode.GDsubscribe1Objects1});
gdjs.MainMenuCode.eventsList15 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
{gdjs.MainMenuCode.conditionTrue_1 = gdjs.MainMenuCode.condition0IsTrue_0;
gdjs.MainMenuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16052020);
}
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.MainMenuCode.eventsList16 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainMenuCode.GDsubscribe1Objects1, gdjs.MainMenuCode.GDsubscribe1Objects2);

{for(var i = 0, len = gdjs.MainMenuCode.GDsubscribe1Objects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDsubscribe1Objects2[i].setAnimationName("StartPressed");
}
}
{ //Subevents
gdjs.MainMenuCode.eventsList15(runtimeScene);} //End of subevents
}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.window.openURL("https://www.youtube.com/@sdcgame", runtimeScene);
}}

}


};gdjs.MainMenuCode.eventsList17 = function(runtimeScene) {

{


gdjs.MainMenuCode.eventsList0(runtimeScene);
}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.adMob.setupBanner("ca-app-pub-7829362827039995~7807956182", "", true);
}{gdjs.adMob.loadInterstitial("ca-app-pub-7829362827039995/8454274703", "", false);
}{gdjs.adMob.loadRewardedVideo("ca-app-pub-7829362827039995/9575784689", "", false);
}}

}


{


{
{gdjs.adMob.showBanner();
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Red_AB1"), gdjs.MainMenuCode.GDRed_95AB1Objects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDRed_9595AB1Objects1Objects, runtimeScene, true, true);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDRed_95AB1Objects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDRed_95AB1Objects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDRed_95AB1Objects1[i].setAnimationName("StartNormal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Red_AB1"), gdjs.MainMenuCode.GDRed_95AB1Objects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDRed_9595AB1Objects1Objects, runtimeScene, true, false);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDRed_95AB1Objects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDRed_95AB1Objects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDRed_95AB1Objects1[i].setAnimationName("StartHover");
}
}
{ //Subevents
gdjs.MainMenuCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HRunner_B1"), gdjs.MainMenuCode.GDHRunner_95B1Objects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDHRunner_9595B1Objects1Objects, runtimeScene, true, true);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDHRunner_95B1Objects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDHRunner_95B1Objects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDHRunner_95B1Objects1[i].setAnimationName("StartNormal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HRunner_B1"), gdjs.MainMenuCode.GDHRunner_95B1Objects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDHRunner_9595B1Objects1Objects, runtimeScene, true, false);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDHRunner_95B1Objects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDHRunner_95B1Objects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDHRunner_95B1Objects1[i].setAnimationName("StartHover");
}
}
{ //Subevents
gdjs.MainMenuCode.eventsList4(runtimeScene);} //End of subevents
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HalicopterA_B1"), gdjs.MainMenuCode.GDHalicopterA_95B1Objects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDHalicopterA_9595B1Objects1Objects, runtimeScene, true, true);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDHalicopterA_95B1Objects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDHalicopterA_95B1Objects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDHalicopterA_95B1Objects1[i].setAnimationName("StartNormal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HalicopterA_B1"), gdjs.MainMenuCode.GDHalicopterA_95B1Objects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDHalicopterA_9595B1Objects1Objects, runtimeScene, true, false);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDHalicopterA_95B1Objects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDHalicopterA_95B1Objects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDHalicopterA_95B1Objects1[i].setAnimationName("StartHover");
}
}
{ //Subevents
gdjs.MainMenuCode.eventsList6(runtimeScene);} //End of subevents
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SnakesA_B1"), gdjs.MainMenuCode.GDSnakesA_95B1Objects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDSnakesA_9595B1Objects1Objects, runtimeScene, true, true);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDSnakesA_95B1Objects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDSnakesA_95B1Objects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDSnakesA_95B1Objects1[i].setAnimationName("StartNormal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SnakesA_B1"), gdjs.MainMenuCode.GDSnakesA_95B1Objects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDSnakesA_9595B1Objects1Objects, runtimeScene, true, false);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDSnakesA_95B1Objects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDSnakesA_95B1Objects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDSnakesA_95B1Objects1[i].setAnimationName("StartHover");
}
}
{ //Subevents
gdjs.MainMenuCode.eventsList8(runtimeScene);} //End of subevents
}

}


{


{
}

}


{


{
}

}


{


gdjs.MainMenuCode.eventsList9(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("exit"), gdjs.MainMenuCode.GDexitObjects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDexitObjects1Objects, runtimeScene, true, true);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDexitObjects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDexitObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDexitObjects1[i].setAnimationName("StartNormal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("exit"), gdjs.MainMenuCode.GDexitObjects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDexitObjects1Objects, runtimeScene, true, false);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDexitObjects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDexitObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDexitObjects1[i].setAnimationName("StartHover");
}
}
{ //Subevents
gdjs.MainMenuCode.eventsList11(runtimeScene);} //End of subevents
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ADb1"), gdjs.MainMenuCode.GDADb1Objects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDADb1Objects1Objects, runtimeScene, true, true);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDADb1Objects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDADb1Objects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDADb1Objects1[i].setAnimationName("StartNormal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ADb1"), gdjs.MainMenuCode.GDADb1Objects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDADb1Objects1Objects, runtimeScene, true, false);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDADb1Objects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDADb1Objects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDADb1Objects1[i].setAnimationName("StartHover");
}
}
{ //Subevents
gdjs.MainMenuCode.eventsList13(runtimeScene);} //End of subevents
}

}


{


{
}

}


{


gdjs.MainMenuCode.eventsList14(runtimeScene);
}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("subscribe1"), gdjs.MainMenuCode.GDsubscribe1Objects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDsubscribe1Objects1Objects, runtimeScene, true, true);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDsubscribe1Objects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDsubscribe1Objects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDsubscribe1Objects1[i].setAnimationName("StartNormal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("subscribe1"), gdjs.MainMenuCode.GDsubscribe1Objects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDsubscribe1Objects1Objects, runtimeScene, true, false);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDsubscribe1Objects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDsubscribe1Objects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDsubscribe1Objects1[i].setAnimationName("StartHover");
}
}
{ //Subevents
gdjs.MainMenuCode.eventsList16(runtimeScene);} //End of subevents
}

}


{


{
}

}


};

gdjs.MainMenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MainMenuCode.GDSky1Objects1.length = 0;
gdjs.MainMenuCode.GDSky1Objects2.length = 0;
gdjs.MainMenuCode.GDSky1Objects3.length = 0;
gdjs.MainMenuCode.GDstObjects1.length = 0;
gdjs.MainMenuCode.GDstObjects2.length = 0;
gdjs.MainMenuCode.GDstObjects3.length = 0;
gdjs.MainMenuCode.GDtcObjects1.length = 0;
gdjs.MainMenuCode.GDtcObjects2.length = 0;
gdjs.MainMenuCode.GDtcObjects3.length = 0;
gdjs.MainMenuCode.GDsubscribe1Objects1.length = 0;
gdjs.MainMenuCode.GDsubscribe1Objects2.length = 0;
gdjs.MainMenuCode.GDsubscribe1Objects3.length = 0;
gdjs.MainMenuCode.GDInfoMObjects1.length = 0;
gdjs.MainMenuCode.GDInfoMObjects2.length = 0;
gdjs.MainMenuCode.GDInfoMObjects3.length = 0;
gdjs.MainMenuCode.GDBorder1Objects1.length = 0;
gdjs.MainMenuCode.GDBorder1Objects2.length = 0;
gdjs.MainMenuCode.GDBorder1Objects3.length = 0;
gdjs.MainMenuCode.GDG_95titalObjects1.length = 0;
gdjs.MainMenuCode.GDG_95titalObjects2.length = 0;
gdjs.MainMenuCode.GDG_95titalObjects3.length = 0;
gdjs.MainMenuCode.GDexitObjects1.length = 0;
gdjs.MainMenuCode.GDexitObjects2.length = 0;
gdjs.MainMenuCode.GDexitObjects3.length = 0;
gdjs.MainMenuCode.GDsdcreationsObjects1.length = 0;
gdjs.MainMenuCode.GDsdcreationsObjects2.length = 0;
gdjs.MainMenuCode.GDsdcreationsObjects3.length = 0;
gdjs.MainMenuCode.GDefa1Objects1.length = 0;
gdjs.MainMenuCode.GDefa1Objects2.length = 0;
gdjs.MainMenuCode.GDefa1Objects3.length = 0;
gdjs.MainMenuCode.GDSnakesA_95B1Objects1.length = 0;
gdjs.MainMenuCode.GDSnakesA_95B1Objects2.length = 0;
gdjs.MainMenuCode.GDSnakesA_95B1Objects3.length = 0;
gdjs.MainMenuCode.GDRed_95AB1Objects1.length = 0;
gdjs.MainMenuCode.GDRed_95AB1Objects2.length = 0;
gdjs.MainMenuCode.GDRed_95AB1Objects3.length = 0;
gdjs.MainMenuCode.GDHRunner_95B1Objects1.length = 0;
gdjs.MainMenuCode.GDHRunner_95B1Objects2.length = 0;
gdjs.MainMenuCode.GDHRunner_95B1Objects3.length = 0;
gdjs.MainMenuCode.GDHalicopterA_95B1Objects1.length = 0;
gdjs.MainMenuCode.GDHalicopterA_95B1Objects2.length = 0;
gdjs.MainMenuCode.GDHalicopterA_95B1Objects3.length = 0;
gdjs.MainMenuCode.GDADb1Objects1.length = 0;
gdjs.MainMenuCode.GDADb1Objects2.length = 0;
gdjs.MainMenuCode.GDADb1Objects3.length = 0;
gdjs.MainMenuCode.GDHands1Objects1.length = 0;
gdjs.MainMenuCode.GDHands1Objects2.length = 0;
gdjs.MainMenuCode.GDHands1Objects3.length = 0;

gdjs.MainMenuCode.eventsList17(runtimeScene);

return;

}

gdjs['MainMenuCode'] = gdjs.MainMenuCode;
