gdjs.Level3Code = {};
gdjs.Level3Code.forEachCount0_2 = 0;

gdjs.Level3Code.forEachCount10_2 = 0;

gdjs.Level3Code.forEachCount1_2 = 0;

gdjs.Level3Code.forEachCount2_2 = 0;

gdjs.Level3Code.forEachCount3_2 = 0;

gdjs.Level3Code.forEachCount4_2 = 0;

gdjs.Level3Code.forEachCount5_2 = 0;

gdjs.Level3Code.forEachCount6_2 = 0;

gdjs.Level3Code.forEachCount7_2 = 0;

gdjs.Level3Code.forEachCount8_2 = 0;

gdjs.Level3Code.forEachCount9_2 = 0;

gdjs.Level3Code.forEachIndex2 = 0;

gdjs.Level3Code.forEachObjects2 = [];

gdjs.Level3Code.forEachTemporary2 = null;

gdjs.Level3Code.forEachTotalCount2 = 0;

gdjs.Level3Code.GDBorder1Objects1= [];
gdjs.Level3Code.GDBorder1Objects2= [];
gdjs.Level3Code.GDBorder1Objects3= [];
gdjs.Level3Code.GDBorder1Objects4= [];
gdjs.Level3Code.GDb1Objects1= [];
gdjs.Level3Code.GDb1Objects2= [];
gdjs.Level3Code.GDb1Objects3= [];
gdjs.Level3Code.GDb1Objects4= [];
gdjs.Level3Code.GDShape1Objects1= [];
gdjs.Level3Code.GDShape1Objects2= [];
gdjs.Level3Code.GDShape1Objects3= [];
gdjs.Level3Code.GDShape1Objects4= [];
gdjs.Level3Code.GDShape8Objects1= [];
gdjs.Level3Code.GDShape8Objects2= [];
gdjs.Level3Code.GDShape8Objects3= [];
gdjs.Level3Code.GDShape8Objects4= [];
gdjs.Level3Code.GDShape2Objects1= [];
gdjs.Level3Code.GDShape2Objects2= [];
gdjs.Level3Code.GDShape2Objects3= [];
gdjs.Level3Code.GDShape2Objects4= [];
gdjs.Level3Code.GDShape9Objects1= [];
gdjs.Level3Code.GDShape9Objects2= [];
gdjs.Level3Code.GDShape9Objects3= [];
gdjs.Level3Code.GDShape9Objects4= [];
gdjs.Level3Code.GDShape3Objects1= [];
gdjs.Level3Code.GDShape3Objects2= [];
gdjs.Level3Code.GDShape3Objects3= [];
gdjs.Level3Code.GDShape3Objects4= [];
gdjs.Level3Code.GDShape10Objects1= [];
gdjs.Level3Code.GDShape10Objects2= [];
gdjs.Level3Code.GDShape10Objects3= [];
gdjs.Level3Code.GDShape10Objects4= [];
gdjs.Level3Code.GDShape4Objects1= [];
gdjs.Level3Code.GDShape4Objects2= [];
gdjs.Level3Code.GDShape4Objects3= [];
gdjs.Level3Code.GDShape4Objects4= [];
gdjs.Level3Code.GDShape11Objects1= [];
gdjs.Level3Code.GDShape11Objects2= [];
gdjs.Level3Code.GDShape11Objects3= [];
gdjs.Level3Code.GDShape11Objects4= [];
gdjs.Level3Code.GDShape5Objects1= [];
gdjs.Level3Code.GDShape5Objects2= [];
gdjs.Level3Code.GDShape5Objects3= [];
gdjs.Level3Code.GDShape5Objects4= [];
gdjs.Level3Code.GDShape6Objects1= [];
gdjs.Level3Code.GDShape6Objects2= [];
gdjs.Level3Code.GDShape6Objects3= [];
gdjs.Level3Code.GDShape6Objects4= [];
gdjs.Level3Code.GDShape7Objects1= [];
gdjs.Level3Code.GDShape7Objects2= [];
gdjs.Level3Code.GDShape7Objects3= [];
gdjs.Level3Code.GDShape7Objects4= [];
gdjs.Level3Code.GDScoreObjects1= [];
gdjs.Level3Code.GDScoreObjects2= [];
gdjs.Level3Code.GDScoreObjects3= [];
gdjs.Level3Code.GDScoreObjects4= [];
gdjs.Level3Code.GDObstacleObjects1= [];
gdjs.Level3Code.GDObstacleObjects2= [];
gdjs.Level3Code.GDObstacleObjects3= [];
gdjs.Level3Code.GDObstacleObjects4= [];
gdjs.Level3Code.GDLifeObjects1= [];
gdjs.Level3Code.GDLifeObjects2= [];
gdjs.Level3Code.GDLifeObjects3= [];
gdjs.Level3Code.GDLifeObjects4= [];
gdjs.Level3Code.GDGameOverObjects1= [];
gdjs.Level3Code.GDGameOverObjects2= [];
gdjs.Level3Code.GDGameOverObjects3= [];
gdjs.Level3Code.GDGameOverObjects4= [];
gdjs.Level3Code.GDButtonTryAgainObjects1= [];
gdjs.Level3Code.GDButtonTryAgainObjects2= [];
gdjs.Level3Code.GDButtonTryAgainObjects3= [];
gdjs.Level3Code.GDButtonTryAgainObjects4= [];
gdjs.Level3Code.GDShape7ExplosionObjects1= [];
gdjs.Level3Code.GDShape7ExplosionObjects2= [];
gdjs.Level3Code.GDShape7ExplosionObjects3= [];
gdjs.Level3Code.GDShape7ExplosionObjects4= [];
gdjs.Level3Code.GDShape6ExplosionObjects1= [];
gdjs.Level3Code.GDShape6ExplosionObjects2= [];
gdjs.Level3Code.GDShape6ExplosionObjects3= [];
gdjs.Level3Code.GDShape6ExplosionObjects4= [];
gdjs.Level3Code.GDShape5ExplosionObjects1= [];
gdjs.Level3Code.GDShape5ExplosionObjects2= [];
gdjs.Level3Code.GDShape5ExplosionObjects3= [];
gdjs.Level3Code.GDShape5ExplosionObjects4= [];
gdjs.Level3Code.GDShape4ExplosionObjects1= [];
gdjs.Level3Code.GDShape4ExplosionObjects2= [];
gdjs.Level3Code.GDShape4ExplosionObjects3= [];
gdjs.Level3Code.GDShape4ExplosionObjects4= [];
gdjs.Level3Code.GDShape11ExplosionObjects1= [];
gdjs.Level3Code.GDShape11ExplosionObjects2= [];
gdjs.Level3Code.GDShape11ExplosionObjects3= [];
gdjs.Level3Code.GDShape11ExplosionObjects4= [];
gdjs.Level3Code.GDShape3ExplosionObjects1= [];
gdjs.Level3Code.GDShape3ExplosionObjects2= [];
gdjs.Level3Code.GDShape3ExplosionObjects3= [];
gdjs.Level3Code.GDShape3ExplosionObjects4= [];
gdjs.Level3Code.GDShape10ExplosionObjects1= [];
gdjs.Level3Code.GDShape10ExplosionObjects2= [];
gdjs.Level3Code.GDShape10ExplosionObjects3= [];
gdjs.Level3Code.GDShape10ExplosionObjects4= [];
gdjs.Level3Code.GDShape2ExplosionObjects1= [];
gdjs.Level3Code.GDShape2ExplosionObjects2= [];
gdjs.Level3Code.GDShape2ExplosionObjects3= [];
gdjs.Level3Code.GDShape2ExplosionObjects4= [];
gdjs.Level3Code.GDShape9ExplosionObjects1= [];
gdjs.Level3Code.GDShape9ExplosionObjects2= [];
gdjs.Level3Code.GDShape9ExplosionObjects3= [];
gdjs.Level3Code.GDShape9ExplosionObjects4= [];
gdjs.Level3Code.GDShape1ExplosionObjects1= [];
gdjs.Level3Code.GDShape1ExplosionObjects2= [];
gdjs.Level3Code.GDShape1ExplosionObjects3= [];
gdjs.Level3Code.GDShape1ExplosionObjects4= [];
gdjs.Level3Code.GDShape8ExplosionObjects1= [];
gdjs.Level3Code.GDShape8ExplosionObjects2= [];
gdjs.Level3Code.GDShape8ExplosionObjects3= [];
gdjs.Level3Code.GDShape8ExplosionObjects4= [];
gdjs.Level3Code.GDButtonMainMenuObjects1= [];
gdjs.Level3Code.GDButtonMainMenuObjects2= [];
gdjs.Level3Code.GDButtonMainMenuObjects3= [];
gdjs.Level3Code.GDButtonMainMenuObjects4= [];
gdjs.Level3Code.GDPauseObjects1= [];
gdjs.Level3Code.GDPauseObjects2= [];
gdjs.Level3Code.GDPauseObjects3= [];
gdjs.Level3Code.GDPauseObjects4= [];
gdjs.Level3Code.GDplayer1Objects1= [];
gdjs.Level3Code.GDplayer1Objects2= [];
gdjs.Level3Code.GDplayer1Objects3= [];
gdjs.Level3Code.GDplayer1Objects4= [];
gdjs.Level3Code.GDNewTextObjects1= [];
gdjs.Level3Code.GDNewTextObjects2= [];
gdjs.Level3Code.GDNewTextObjects3= [];
gdjs.Level3Code.GDNewTextObjects4= [];
gdjs.Level3Code.GDRight1Objects1= [];
gdjs.Level3Code.GDRight1Objects2= [];
gdjs.Level3Code.GDRight1Objects3= [];
gdjs.Level3Code.GDRight1Objects4= [];
gdjs.Level3Code.GDLeft1Objects1= [];
gdjs.Level3Code.GDLeft1Objects2= [];
gdjs.Level3Code.GDLeft1Objects3= [];
gdjs.Level3Code.GDLeft1Objects4= [];
gdjs.Level3Code.GDBGS1Objects1= [];
gdjs.Level3Code.GDBGS1Objects2= [];
gdjs.Level3Code.GDBGS1Objects3= [];
gdjs.Level3Code.GDBGS1Objects4= [];
gdjs.Level3Code.GDMainMenu2Objects1= [];
gdjs.Level3Code.GDMainMenu2Objects2= [];
gdjs.Level3Code.GDMainMenu2Objects3= [];
gdjs.Level3Code.GDMainMenu2Objects4= [];
gdjs.Level3Code.GDEarth1Objects1= [];
gdjs.Level3Code.GDEarth1Objects2= [];
gdjs.Level3Code.GDEarth1Objects3= [];
gdjs.Level3Code.GDEarth1Objects4= [];

gdjs.Level3Code.conditionTrue_0 = {val:false};
gdjs.Level3Code.condition0IsTrue_0 = {val:false};
gdjs.Level3Code.condition1IsTrue_0 = {val:false};
gdjs.Level3Code.conditionTrue_1 = {val:false};
gdjs.Level3Code.condition0IsTrue_1 = {val:false};
gdjs.Level3Code.condition1IsTrue_1 = {val:false};


gdjs.Level3Code.eventsList0 = function(runtimeScene) {

};gdjs.Level3Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects2);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level3Code.GDplayer1Objects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDplayer1Objects2[i].getX() > gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) + 5 ) {
        gdjs.Level3Code.condition0IsTrue_0.val = true;
        gdjs.Level3Code.GDplayer1Objects2[k] = gdjs.Level3Code.GDplayer1Objects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDplayer1Objects2.length = k;}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDplayer1Objects2 */
{for(var i = 0, len = gdjs.Level3Code.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.Level3Code.GDplayer1Objects2[i].addForce(-(450), 0, 0);
}
}{for(var i = 0, len = gdjs.Level3Code.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.Level3Code.GDplayer1Objects2[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level3Code.GDplayer1Objects1.length;i<l;++i) {
    if ( gdjs.Level3Code.GDplayer1Objects1[i].getX() < gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) - 5 ) {
        gdjs.Level3Code.condition0IsTrue_0.val = true;
        gdjs.Level3Code.GDplayer1Objects1[k] = gdjs.Level3Code.GDplayer1Objects1[i];
        ++k;
    }
}
gdjs.Level3Code.GDplayer1Objects1.length = k;}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDplayer1Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDplayer1Objects1[i].addForce(450, 0, 0);
}
}{for(var i = 0, len = gdjs.Level3Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDplayer1Objects1[i].setAnimation(2);
}
}}

}


};gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape1Objects1ObjectsGDgdjs_46Level3Code_46GDShape2Objects1ObjectsGDgdjs_46Level3Code_46GDShape3Objects1ObjectsGDgdjs_46Level3Code_46GDShape4Objects1ObjectsGDgdjs_46Level3Code_46GDShape5Objects1ObjectsGDgdjs_46Level3Code_46GDShape6Objects1ObjectsGDgdjs_46Level3Code_46GDShape7Objects1ObjectsGDgdjs_46Level3Code_46GDShape8Objects1ObjectsGDgdjs_46Level3Code_46GDShape9Objects1ObjectsGDgdjs_46Level3Code_46GDShape10Objects1ObjectsGDgdjs_46Level3Code_46GDShape11Objects1Objects = Hashtable.newFrom({"Shape1": gdjs.Level3Code.GDShape1Objects1, "Shape2": gdjs.Level3Code.GDShape2Objects1, "Shape3": gdjs.Level3Code.GDShape3Objects1, "Shape4": gdjs.Level3Code.GDShape4Objects1, "Shape5": gdjs.Level3Code.GDShape5Objects1, "Shape6": gdjs.Level3Code.GDShape6Objects1, "Shape7": gdjs.Level3Code.GDShape7Objects1, "Shape8": gdjs.Level3Code.GDShape8Objects1, "Shape9": gdjs.Level3Code.GDShape9Objects1, "Shape10": gdjs.Level3Code.GDShape10Objects1, "Shape11": gdjs.Level3Code.GDShape11Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape1Objects2Objects = Hashtable.newFrom({"Shape1": gdjs.Level3Code.GDShape1Objects2});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects2Objects = Hashtable.newFrom({"player1": gdjs.Level3Code.GDplayer1Objects2});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape1Objects3Objects = Hashtable.newFrom({"Shape1": gdjs.Level3Code.GDShape1Objects3});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape1ExplosionObjects3Objects = Hashtable.newFrom({"Shape1Explosion": gdjs.Level3Code.GDShape1ExplosionObjects3});
gdjs.Level3Code.eventsList2 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.Level3Code.GDShape1Objects2, gdjs.Level3Code.GDShape1Objects3);


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape1Objects3Objects) != 0;
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDShape1Objects3 */
gdjs.Level3Code.GDShape1ExplosionObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape1ExplosionObjects3Objects, (( gdjs.Level3Code.GDShape1Objects3.length === 0 ) ? 0 :gdjs.Level3Code.GDShape1Objects3[0].getPointX("Center")), (( gdjs.Level3Code.GDShape1Objects3.length === 0 ) ? 0 :gdjs.Level3Code.GDShape1Objects3[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.Level3Code.GDShape1ExplosionObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDShape1ExplosionObjects3[i].setParticleSize1((( gdjs.Level3Code.GDShape1Objects3.length === 0 ) ? 0 :gdjs.Level3Code.GDShape1Objects3[0].getWidth()));
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level3Code.GDScoreObjects3);
gdjs.copyArray(gdjs.Level3Code.GDShape1Objects2, gdjs.Level3Code.GDShape1Objects3);

{for(var i = 0, len = gdjs.Level3Code.GDShape1Objects3.length ;i < len;++i) {
    gdjs.Level3Code.GDShape1Objects3[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "baby_laugh1.mp3", false, 100, 1);
}{runtimeScene.getScene().getVariables().get("Score").add(1);
}{for(var i = 0, len = gdjs.Level3Code.GDScoreObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDScoreObjects3[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Score"))));
}
}}

}


};gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape2Objects1Objects = Hashtable.newFrom({"Shape2": gdjs.Level3Code.GDShape2Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.Level3Code.GDplayer1Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape2Objects2Objects = Hashtable.newFrom({"Shape2": gdjs.Level3Code.GDShape2Objects2});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape2ExplosionObjects2Objects = Hashtable.newFrom({"Shape2Explosion": gdjs.Level3Code.GDShape2ExplosionObjects2});
gdjs.Level3Code.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level3Code.GDShape2Objects1, gdjs.Level3Code.GDShape2Objects2);


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape2Objects2Objects) != 0;
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDShape2Objects2 */
gdjs.Level3Code.GDShape2ExplosionObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape2ExplosionObjects2Objects, (( gdjs.Level3Code.GDShape2Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape2Objects2[0].getPointX("Center")), (( gdjs.Level3Code.GDShape2Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape2Objects2[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.Level3Code.GDShape2ExplosionObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDShape2ExplosionObjects2[i].setParticleSize1((( gdjs.Level3Code.GDShape2Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape2Objects2[0].getWidth()));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level3Code.GDScoreObjects1);
/* Reuse gdjs.Level3Code.GDShape2Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDShape2Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape2Objects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "baby_laugh2.mp3", false, 100, 1);
}{runtimeScene.getScene().getVariables().get("Score").add(1);
}{for(var i = 0, len = gdjs.Level3Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Score"))));
}
}}

}


};gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape3Objects1Objects = Hashtable.newFrom({"Shape3": gdjs.Level3Code.GDShape3Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.Level3Code.GDplayer1Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape3Objects2Objects = Hashtable.newFrom({"Shape3": gdjs.Level3Code.GDShape3Objects2});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape3ExplosionObjects2Objects = Hashtable.newFrom({"Shape3Explosion": gdjs.Level3Code.GDShape3ExplosionObjects2});
gdjs.Level3Code.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level3Code.GDShape3Objects1, gdjs.Level3Code.GDShape3Objects2);


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape3Objects2Objects) != 0;
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDShape3Objects2 */
gdjs.Level3Code.GDShape3ExplosionObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape3ExplosionObjects2Objects, (( gdjs.Level3Code.GDShape3Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape3Objects2[0].getPointX("Center")), (( gdjs.Level3Code.GDShape3Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape3Objects2[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.Level3Code.GDShape3ExplosionObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDShape3ExplosionObjects2[i].setParticleSize1((( gdjs.Level3Code.GDShape3Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape3Objects2[0].getWidth()));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level3Code.GDScoreObjects1);
/* Reuse gdjs.Level3Code.GDShape3Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDShape3Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape3Objects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "baby_laugh3.mp3", false, 100, 1);
}{runtimeScene.getScene().getVariables().get("Score").add(1);
}{for(var i = 0, len = gdjs.Level3Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Score"))));
}
}}

}


};gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape4Objects1Objects = Hashtable.newFrom({"Shape4": gdjs.Level3Code.GDShape4Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.Level3Code.GDplayer1Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape4Objects2Objects = Hashtable.newFrom({"Shape4": gdjs.Level3Code.GDShape4Objects2});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape4ExplosionObjects2Objects = Hashtable.newFrom({"Shape4Explosion": gdjs.Level3Code.GDShape4ExplosionObjects2});
gdjs.Level3Code.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level3Code.GDShape4Objects1, gdjs.Level3Code.GDShape4Objects2);


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape4Objects2Objects) != 0;
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDShape4Objects2 */
gdjs.Level3Code.GDShape4ExplosionObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape4ExplosionObjects2Objects, (( gdjs.Level3Code.GDShape4Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape4Objects2[0].getPointX("Center")), (( gdjs.Level3Code.GDShape4Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape4Objects2[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.Level3Code.GDShape4ExplosionObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDShape4ExplosionObjects2[i].setParticleSize1((( gdjs.Level3Code.GDShape4Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape4Objects2[0].getWidth()));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level3Code.GDScoreObjects1);
/* Reuse gdjs.Level3Code.GDShape4Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDShape4Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape4Objects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "baby_laugh4.mp3", false, 100, 1);
}{runtimeScene.getScene().getVariables().get("Score").add(1);
}{for(var i = 0, len = gdjs.Level3Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Score"))));
}
}}

}


};gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape5Objects1Objects = Hashtable.newFrom({"Shape5": gdjs.Level3Code.GDShape5Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.Level3Code.GDplayer1Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape5Objects2Objects = Hashtable.newFrom({"Shape5": gdjs.Level3Code.GDShape5Objects2});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape5ExplosionObjects2Objects = Hashtable.newFrom({"Shape5Explosion": gdjs.Level3Code.GDShape5ExplosionObjects2});
gdjs.Level3Code.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level3Code.GDShape5Objects1, gdjs.Level3Code.GDShape5Objects2);


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape5Objects2Objects) != 0;
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDShape5Objects2 */
gdjs.Level3Code.GDShape5ExplosionObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape5ExplosionObjects2Objects, (( gdjs.Level3Code.GDShape5Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape5Objects2[0].getPointX("Center")), (( gdjs.Level3Code.GDShape5Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape5Objects2[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.Level3Code.GDShape5ExplosionObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDShape5ExplosionObjects2[i].setParticleSize1((( gdjs.Level3Code.GDShape5Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape5Objects2[0].getWidth()));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level3Code.GDScoreObjects1);
/* Reuse gdjs.Level3Code.GDShape5Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDShape5Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape5Objects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "CoinS1S.mp3", false, 100, 1);
}{runtimeScene.getScene().getVariables().get("Score").add(1);
}{for(var i = 0, len = gdjs.Level3Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Score"))));
}
}}

}


};gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape6Objects1Objects = Hashtable.newFrom({"Shape6": gdjs.Level3Code.GDShape6Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.Level3Code.GDplayer1Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape6Objects2Objects = Hashtable.newFrom({"Shape6": gdjs.Level3Code.GDShape6Objects2});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape6ExplosionObjects2Objects = Hashtable.newFrom({"Shape6Explosion": gdjs.Level3Code.GDShape6ExplosionObjects2});
gdjs.Level3Code.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level3Code.GDShape6Objects1, gdjs.Level3Code.GDShape6Objects2);


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape6Objects2Objects) != 0;
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDShape6Objects2 */
gdjs.Level3Code.GDShape6ExplosionObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape6ExplosionObjects2Objects, (( gdjs.Level3Code.GDShape6Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape6Objects2[0].getPointX("Center")), (( gdjs.Level3Code.GDShape6Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape6Objects2[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.Level3Code.GDShape6ExplosionObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDShape6ExplosionObjects2[i].setParticleSize1((gdjs.Level3Code.GDShape6ExplosionObjects2[i].getWidth()));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level3Code.GDScoreObjects1);
/* Reuse gdjs.Level3Code.GDShape6Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDShape6Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape6Objects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "CoinS1S.mp3", false, 100, 1);
}{runtimeScene.getScene().getVariables().get("Score").add(1);
}{for(var i = 0, len = gdjs.Level3Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Score"))));
}
}}

}


};gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape7Objects1Objects = Hashtable.newFrom({"Shape7": gdjs.Level3Code.GDShape7Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.Level3Code.GDplayer1Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape7Objects2Objects = Hashtable.newFrom({"Shape7": gdjs.Level3Code.GDShape7Objects2});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape7ExplosionObjects2Objects = Hashtable.newFrom({"Shape7Explosion": gdjs.Level3Code.GDShape7ExplosionObjects2});
gdjs.Level3Code.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level3Code.GDShape7Objects1, gdjs.Level3Code.GDShape7Objects2);


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape7Objects2Objects) != 0;
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDShape7Objects2 */
gdjs.Level3Code.GDShape7ExplosionObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape7ExplosionObjects2Objects, (( gdjs.Level3Code.GDShape7Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape7Objects2[0].getPointX("Center")), (( gdjs.Level3Code.GDShape7Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape7Objects2[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.Level3Code.GDShape7ExplosionObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDShape7ExplosionObjects2[i].setParticleSize1((( gdjs.Level3Code.GDShape7Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape7Objects2[0].getWidth()));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level3Code.GDScoreObjects1);
/* Reuse gdjs.Level3Code.GDShape7Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDShape7Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape7Objects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "CoinS1S.mp3", false, 100, 1);
}{runtimeScene.getScene().getVariables().get("Score").add(1);
}{for(var i = 0, len = gdjs.Level3Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Score"))));
}
}}

}


};gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape8Objects2Objects = Hashtable.newFrom({"Shape8": gdjs.Level3Code.GDShape8Objects2});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects2Objects = Hashtable.newFrom({"player1": gdjs.Level3Code.GDplayer1Objects2});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape8Objects3Objects = Hashtable.newFrom({"Shape8": gdjs.Level3Code.GDShape8Objects3});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape8ExplosionObjects3Objects = Hashtable.newFrom({"Shape8Explosion": gdjs.Level3Code.GDShape8ExplosionObjects3});
gdjs.Level3Code.eventsList9 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.Level3Code.GDShape8Objects2, gdjs.Level3Code.GDShape8Objects3);


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape8Objects3Objects) != 0;
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDShape8Objects3 */
gdjs.Level3Code.GDShape8ExplosionObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape8ExplosionObjects3Objects, (( gdjs.Level3Code.GDShape8Objects3.length === 0 ) ? 0 :gdjs.Level3Code.GDShape8Objects3[0].getPointX("Center")), (( gdjs.Level3Code.GDShape8Objects3.length === 0 ) ? 0 :gdjs.Level3Code.GDShape8Objects3[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.Level3Code.GDShape8ExplosionObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDShape8ExplosionObjects3[i].setParticleSize1((( gdjs.Level3Code.GDShape8Objects3.length === 0 ) ? 0 :gdjs.Level3Code.GDShape8Objects3[0].getWidth()));
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level3Code.GDScoreObjects3);
gdjs.copyArray(gdjs.Level3Code.GDShape8Objects2, gdjs.Level3Code.GDShape8Objects3);

{for(var i = 0, len = gdjs.Level3Code.GDShape8Objects3.length ;i < len;++i) {
    gdjs.Level3Code.GDShape8Objects3[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "baby_laugh1.mp3", false, 100, 1);
}{runtimeScene.getScene().getVariables().get("Score").add(1);
}{for(var i = 0, len = gdjs.Level3Code.GDScoreObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDScoreObjects3[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Score"))));
}
}}

}


};gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape9Objects1Objects = Hashtable.newFrom({"Shape9": gdjs.Level3Code.GDShape9Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.Level3Code.GDplayer1Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape9Objects2Objects = Hashtable.newFrom({"Shape9": gdjs.Level3Code.GDShape9Objects2});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape9ExplosionObjects2Objects = Hashtable.newFrom({"Shape9Explosion": gdjs.Level3Code.GDShape9ExplosionObjects2});
gdjs.Level3Code.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level3Code.GDShape9Objects1, gdjs.Level3Code.GDShape9Objects2);


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape9Objects2Objects) != 0;
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDShape9Objects2 */
gdjs.Level3Code.GDShape9ExplosionObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape9ExplosionObjects2Objects, (( gdjs.Level3Code.GDShape9Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape9Objects2[0].getPointX("Center")), (( gdjs.Level3Code.GDShape9Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape9Objects2[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.Level3Code.GDShape9ExplosionObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDShape9ExplosionObjects2[i].setParticleSize1((( gdjs.Level3Code.GDShape9Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape9Objects2[0].getWidth()));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level3Code.GDScoreObjects1);
/* Reuse gdjs.Level3Code.GDShape9Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDShape9Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape9Objects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "baby_laugh2.mp3", false, 100, 1);
}{runtimeScene.getScene().getVariables().get("Score").add(1);
}{for(var i = 0, len = gdjs.Level3Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Score"))));
}
}}

}


};gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape10Objects1Objects = Hashtable.newFrom({"Shape10": gdjs.Level3Code.GDShape10Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.Level3Code.GDplayer1Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape10Objects2Objects = Hashtable.newFrom({"Shape10": gdjs.Level3Code.GDShape10Objects2});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape10ExplosionObjects2Objects = Hashtable.newFrom({"Shape10Explosion": gdjs.Level3Code.GDShape10ExplosionObjects2});
gdjs.Level3Code.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level3Code.GDShape10Objects1, gdjs.Level3Code.GDShape10Objects2);


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape10Objects2Objects) != 0;
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDShape10Objects2 */
gdjs.Level3Code.GDShape10ExplosionObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape10ExplosionObjects2Objects, (( gdjs.Level3Code.GDShape10Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape10Objects2[0].getPointX("Center")), (( gdjs.Level3Code.GDShape10Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape10Objects2[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.Level3Code.GDShape10ExplosionObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDShape10ExplosionObjects2[i].setParticleSize1((( gdjs.Level3Code.GDShape10Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape10Objects2[0].getWidth()));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level3Code.GDScoreObjects1);
/* Reuse gdjs.Level3Code.GDShape10Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDShape10Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape10Objects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "baby_laugh3.mp3", false, 100, 1);
}{runtimeScene.getScene().getVariables().get("Score").add(1);
}{for(var i = 0, len = gdjs.Level3Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Score"))));
}
}}

}


};gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape11Objects1Objects = Hashtable.newFrom({"Shape11": gdjs.Level3Code.GDShape11Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.Level3Code.GDplayer1Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape11Objects2Objects = Hashtable.newFrom({"Shape11": gdjs.Level3Code.GDShape11Objects2});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape11ExplosionObjects2Objects = Hashtable.newFrom({"Shape11Explosion": gdjs.Level3Code.GDShape11ExplosionObjects2});
gdjs.Level3Code.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level3Code.GDShape11Objects1, gdjs.Level3Code.GDShape11Objects2);


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape11Objects2Objects) != 0;
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDShape11Objects2 */
gdjs.Level3Code.GDShape11ExplosionObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape11ExplosionObjects2Objects, (( gdjs.Level3Code.GDShape11Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape11Objects2[0].getPointX("Center")), (( gdjs.Level3Code.GDShape11Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape11Objects2[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.Level3Code.GDShape11ExplosionObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDShape11ExplosionObjects2[i].setParticleSize1((( gdjs.Level3Code.GDShape11Objects2.length === 0 ) ? 0 :gdjs.Level3Code.GDShape11Objects2[0].getWidth()));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level3Code.GDScoreObjects1);
/* Reuse gdjs.Level3Code.GDShape11Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDShape11Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape11Objects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "baby_laugh4.mp3", false, 100, 1);
}{runtimeScene.getScene().getVariables().get("Score").add(1);
}{for(var i = 0, len = gdjs.Level3Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Score"))));
}
}}

}


};gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDObstacleObjects2Objects = Hashtable.newFrom({"Obstacle": gdjs.Level3Code.GDObstacleObjects2});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects2Objects = Hashtable.newFrom({"player1": gdjs.Level3Code.GDplayer1Objects2});
gdjs.Level3Code.eventsList13 = function(runtimeScene) {

};gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDObstacleObjects1Objects = Hashtable.newFrom({"Obstacle": gdjs.Level3Code.GDObstacleObjects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDButtonTryAgainObjects2Objects = Hashtable.newFrom({"ButtonTryAgain": gdjs.Level3Code.GDButtonTryAgainObjects2});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDButtonTryAgainObjects2Objects = Hashtable.newFrom({"ButtonTryAgain": gdjs.Level3Code.GDButtonTryAgainObjects2});
gdjs.Level3Code.eventsList14 = function(runtimeScene) {

{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
{gdjs.Level3Code.conditionTrue_1 = gdjs.Level3Code.condition0IsTrue_0;
gdjs.Level3Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16311452);
}
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.Level3Code.eventsList15 = function(runtimeScene) {

{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level3Code.GDButtonTryAgainObjects2, gdjs.Level3Code.GDButtonTryAgainObjects3);

{for(var i = 0, len = gdjs.Level3Code.GDButtonTryAgainObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDButtonTryAgainObjects3[i].setAnimationName("TryAgainPressed");
}
}
{ //Subevents
gdjs.Level3Code.eventsList14(runtimeScene);} //End of subevents
}

}


{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level3", false);
}}

}


};gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDButtonMainMenuObjects2Objects = Hashtable.newFrom({"ButtonMainMenu": gdjs.Level3Code.GDButtonMainMenuObjects2});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDButtonMainMenuObjects1Objects = Hashtable.newFrom({"ButtonMainMenu": gdjs.Level3Code.GDButtonMainMenuObjects1});
gdjs.Level3Code.eventsList16 = function(runtimeScene) {

{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
{gdjs.Level3Code.conditionTrue_1 = gdjs.Level3Code.condition0IsTrue_0;
gdjs.Level3Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16313892);
}
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.Level3Code.eventsList17 = function(runtimeScene) {

{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level3Code.GDButtonMainMenuObjects1, gdjs.Level3Code.GDButtonMainMenuObjects2);

{for(var i = 0, len = gdjs.Level3Code.GDButtonMainMenuObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDButtonMainMenuObjects2[i].setAnimationName("MainMenuPressed");
}
}
{ //Subevents
gdjs.Level3Code.eventsList16(runtimeScene);} //End of subevents
}

}


{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}

}


};gdjs.Level3Code.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level3Code.GDButtonTryAgainObjects1, gdjs.Level3Code.GDButtonTryAgainObjects2);


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDButtonTryAgainObjects2Objects, runtimeScene, true, true);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDButtonTryAgainObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDButtonTryAgainObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDButtonTryAgainObjects2[i].setAnimationName("TryAgainNormal");
}
}}

}


{

gdjs.copyArray(gdjs.Level3Code.GDButtonTryAgainObjects1, gdjs.Level3Code.GDButtonTryAgainObjects2);


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDButtonTryAgainObjects2Objects, runtimeScene, true, false);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDButtonTryAgainObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDButtonTryAgainObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDButtonTryAgainObjects2[i].setAnimationName("TryAgainHover");
}
}
{ //Subevents
gdjs.Level3Code.eventsList15(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Level3Code.GDButtonMainMenuObjects1, gdjs.Level3Code.GDButtonMainMenuObjects2);


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDButtonMainMenuObjects2Objects, runtimeScene, true, true);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDButtonMainMenuObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDButtonMainMenuObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDButtonMainMenuObjects2[i].setAnimationName("MainMenuNormal");
}
}}

}


{

/* Reuse gdjs.Level3Code.GDButtonMainMenuObjects1 */

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDButtonMainMenuObjects1Objects, runtimeScene, true, false);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDButtonMainMenuObjects1 */
{for(var i = 0, len = gdjs.Level3Code.GDButtonMainMenuObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDButtonMainMenuObjects1[i].setAnimationName("MainMenuHover");
}
}
{ //Subevents
gdjs.Level3Code.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.Level3Code.eventsList19 = function(runtimeScene) {

};gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDPauseObjects1Objects = Hashtable.newFrom({"Pause": gdjs.Level3Code.GDPauseObjects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDPauseObjects1Objects = Hashtable.newFrom({"Pause": gdjs.Level3Code.GDPauseObjects1});
gdjs.Level3Code.eventsList20 = function(runtimeScene) {

{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
{gdjs.Level3Code.conditionTrue_1 = gdjs.Level3Code.condition0IsTrue_0;
gdjs.Level3Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16319956);
}
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.Level3Code.eventsList21 = function(runtimeScene) {

{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level3Code.GDPauseObjects1, gdjs.Level3Code.GDPauseObjects2);

{for(var i = 0, len = gdjs.Level3Code.GDPauseObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPauseObjects2[i].setAnimationName("StartPressed");
}
}
{ //Subevents
gdjs.Level3Code.eventsList20(runtimeScene);} //End of subevents
}

}


{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Pause_screen");
}}

}


};gdjs.Level3Code.eventsList22 = function(runtimeScene) {

};gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDMainMenu2Objects1Objects = Hashtable.newFrom({"MainMenu2": gdjs.Level3Code.GDMainMenu2Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDMainMenu2Objects1Objects = Hashtable.newFrom({"MainMenu2": gdjs.Level3Code.GDMainMenu2Objects1});
gdjs.Level3Code.eventsList23 = function(runtimeScene) {

{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
{gdjs.Level3Code.conditionTrue_1 = gdjs.Level3Code.condition0IsTrue_0;
gdjs.Level3Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16323564);
}
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.Level3Code.eventsList24 = function(runtimeScene) {

{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level3Code.GDMainMenu2Objects1, gdjs.Level3Code.GDMainMenu2Objects2);

{for(var i = 0, len = gdjs.Level3Code.GDMainMenu2Objects2.length ;i < len;++i) {
    gdjs.Level3Code.GDMainMenu2Objects2[i].setAnimationName("StartPressed");
}
}
{ //Subevents
gdjs.Level3Code.eventsList23(runtimeScene);} //End of subevents
}

}


{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}

}


};gdjs.Level3Code.eventsList25 = function(runtimeScene) {

};gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDRight1Objects1Objects = Hashtable.newFrom({"Right1": gdjs.Level3Code.GDRight1Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDRight1Objects1Objects = Hashtable.newFrom({"Right1": gdjs.Level3Code.GDRight1Objects1});
gdjs.Level3Code.eventsList26 = function(runtimeScene) {

{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
{gdjs.Level3Code.conditionTrue_1 = gdjs.Level3Code.condition0IsTrue_0;
gdjs.Level3Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16327428);
}
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
}

}


};gdjs.Level3Code.eventsList27 = function(runtimeScene) {

{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level3Code.GDRight1Objects1, gdjs.Level3Code.GDRight1Objects2);

{for(var i = 0, len = gdjs.Level3Code.GDRight1Objects2.length ;i < len;++i) {
    gdjs.Level3Code.GDRight1Objects2[i].setAnimationName("StartPressed");
}
}
{ //Subevents
gdjs.Level3Code.eventsList26(runtimeScene);} //End of subevents
}

}


{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDRight1Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDRight1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDRight1Objects1[i].setAnimationName("StartNormal");
}
}}

}


};gdjs.Level3Code.eventsList28 = function(runtimeScene) {

};gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDLeft1Objects1Objects = Hashtable.newFrom({"Left1": gdjs.Level3Code.GDLeft1Objects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDLeft1Objects1Objects = Hashtable.newFrom({"Left1": gdjs.Level3Code.GDLeft1Objects1});
gdjs.Level3Code.eventsList29 = function(runtimeScene) {

{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
{gdjs.Level3Code.conditionTrue_1 = gdjs.Level3Code.condition0IsTrue_0;
gdjs.Level3Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16331148);
}
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
}

}


};gdjs.Level3Code.eventsList30 = function(runtimeScene) {

{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level3Code.GDLeft1Objects1, gdjs.Level3Code.GDLeft1Objects2);

{for(var i = 0, len = gdjs.Level3Code.GDLeft1Objects2.length ;i < len;++i) {
    gdjs.Level3Code.GDLeft1Objects2[i].setAnimationName("StartPressed");
}
}
{ //Subevents
gdjs.Level3Code.eventsList29(runtimeScene);} //End of subevents
}

}


{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDLeft1Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDLeft1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDLeft1Objects1[i].setAnimationName("StartNormal");
}
}}

}


};gdjs.Level3Code.eventsList31 = function(runtimeScene) {

{


gdjs.Level3Code.eventsList0(runtimeScene);
}


{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
{gdjs.adMob.setupBanner("ca-app-pub-7829362827039995~7807956182", "", true);
}{gdjs.adMob.loadInterstitial("ca-app-pub-7829362827039995/8454274703", "", false);
}{gdjs.adMob.loadRewardedVideo("ca-app-pub-7829362827039995/9575784689", "", false);
}}

}


{


{
{gdjs.adMob.showBanner();
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{



}


{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects1);
{for(var i = 0, len = gdjs.Level3Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDplayer1Objects1[i].addForce(-(450), 0, 0);
}
}{for(var i = 0, len = gdjs.Level3Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDplayer1Objects1[i].setAnimation(1);
}
}}

}


{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Left");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects1);
{for(var i = 0, len = gdjs.Level3Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDplayer1Objects1[i].addForce(-(450), 0, 0);
}
}{for(var i = 0, len = gdjs.Level3Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDplayer1Objects1[i].setAnimation(0);
}
}}

}


{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects1);
{for(var i = 0, len = gdjs.Level3Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDplayer1Objects1[i].addForce(450, 0, 0);
}
}{for(var i = 0, len = gdjs.Level3Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDplayer1Objects1[i].setAnimation(2);
}
}}

}


{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Right");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects1);
{for(var i = 0, len = gdjs.Level3Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDplayer1Objects1[i].addForce(450, 0, 0);
}
}{for(var i = 0, len = gdjs.Level3Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDplayer1Objects1[i].setAnimation(0);
}
}}

}


{


{
}

}


{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.hasTouchEnded(runtimeScene, 0);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects1);
{for(var i = 0, len = gdjs.Level3Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDplayer1Objects1[i].setAnimation(0);
}
}}

}


{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects1);
{for(var i = 0, len = gdjs.Level3Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDplayer1Objects1[i].setAnimation(0);
}
}}

}


{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level3Code.eventsList1(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1.3, "ShapeCreation");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
gdjs.Level3Code.GDShape1Objects1.length = 0;

gdjs.Level3Code.GDShape10Objects1.length = 0;

gdjs.Level3Code.GDShape11Objects1.length = 0;

gdjs.Level3Code.GDShape2Objects1.length = 0;

gdjs.Level3Code.GDShape3Objects1.length = 0;

gdjs.Level3Code.GDShape4Objects1.length = 0;

gdjs.Level3Code.GDShape5Objects1.length = 0;

gdjs.Level3Code.GDShape6Objects1.length = 0;

gdjs.Level3Code.GDShape7Objects1.length = 0;

gdjs.Level3Code.GDShape8Objects1.length = 0;

gdjs.Level3Code.GDShape9Objects1.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape1Objects1ObjectsGDgdjs_46Level3Code_46GDShape2Objects1ObjectsGDgdjs_46Level3Code_46GDShape3Objects1ObjectsGDgdjs_46Level3Code_46GDShape4Objects1ObjectsGDgdjs_46Level3Code_46GDShape5Objects1ObjectsGDgdjs_46Level3Code_46GDShape6Objects1ObjectsGDgdjs_46Level3Code_46GDShape7Objects1ObjectsGDgdjs_46Level3Code_46GDShape8Objects1ObjectsGDgdjs_46Level3Code_46GDShape9Objects1ObjectsGDgdjs_46Level3Code_46GDShape10Objects1ObjectsGDgdjs_46Level3Code_46GDShape11Objects1Objects, "Shape" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 11)), gdjs.randomInRange(80, 640 - 80), 950, "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ShapeCreation");
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Shape1"), gdjs.Level3Code.GDShape1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape10"), gdjs.Level3Code.GDShape10Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape11"), gdjs.Level3Code.GDShape11Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape2"), gdjs.Level3Code.GDShape2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape3"), gdjs.Level3Code.GDShape3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape4"), gdjs.Level3Code.GDShape4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape5"), gdjs.Level3Code.GDShape5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape6"), gdjs.Level3Code.GDShape6Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape7"), gdjs.Level3Code.GDShape7Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape8"), gdjs.Level3Code.GDShape8Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape9"), gdjs.Level3Code.GDShape9Objects1);
{for(var i = 0, len = gdjs.Level3Code.GDShape1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape1Objects1[i].addPolarForce(270, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
for(var i = 0, len = gdjs.Level3Code.GDShape2Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape2Objects1[i].addPolarForce(270, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
for(var i = 0, len = gdjs.Level3Code.GDShape3Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape3Objects1[i].addPolarForce(270, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
for(var i = 0, len = gdjs.Level3Code.GDShape4Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape4Objects1[i].addPolarForce(270, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
for(var i = 0, len = gdjs.Level3Code.GDShape5Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape5Objects1[i].addPolarForce(270, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
for(var i = 0, len = gdjs.Level3Code.GDShape6Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape6Objects1[i].addPolarForce(270, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
for(var i = 0, len = gdjs.Level3Code.GDShape7Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape7Objects1[i].addPolarForce(270, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
for(var i = 0, len = gdjs.Level3Code.GDShape8Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape8Objects1[i].addPolarForce(270, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
for(var i = 0, len = gdjs.Level3Code.GDShape9Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape9Objects1[i].addPolarForce(270, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
for(var i = 0, len = gdjs.Level3Code.GDShape10Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape10Objects1[i].addPolarForce(270, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
for(var i = 0, len = gdjs.Level3Code.GDShape11Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape11Objects1[i].addPolarForce(270, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Shape1"), gdjs.Level3Code.GDShape1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape10"), gdjs.Level3Code.GDShape10Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape11"), gdjs.Level3Code.GDShape11Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape2"), gdjs.Level3Code.GDShape2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape3"), gdjs.Level3Code.GDShape3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape4"), gdjs.Level3Code.GDShape4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape5"), gdjs.Level3Code.GDShape5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape6"), gdjs.Level3Code.GDShape6Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape7"), gdjs.Level3Code.GDShape7Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape8"), gdjs.Level3Code.GDShape8Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape9"), gdjs.Level3Code.GDShape9Objects1);

gdjs.Level3Code.forEachTotalCount2 = 0;
gdjs.Level3Code.forEachObjects2.length = 0;
gdjs.Level3Code.forEachCount0_2 = gdjs.Level3Code.GDShape1Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount0_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape1Objects1);
gdjs.Level3Code.forEachCount1_2 = gdjs.Level3Code.GDShape2Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount1_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape2Objects1);
gdjs.Level3Code.forEachCount2_2 = gdjs.Level3Code.GDShape3Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount2_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape3Objects1);
gdjs.Level3Code.forEachCount3_2 = gdjs.Level3Code.GDShape4Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount3_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape4Objects1);
gdjs.Level3Code.forEachCount4_2 = gdjs.Level3Code.GDShape5Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount4_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape5Objects1);
gdjs.Level3Code.forEachCount5_2 = gdjs.Level3Code.GDShape6Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount5_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape6Objects1);
gdjs.Level3Code.forEachCount6_2 = gdjs.Level3Code.GDShape7Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount6_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape7Objects1);
gdjs.Level3Code.forEachCount7_2 = gdjs.Level3Code.GDShape8Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount7_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape8Objects1);
gdjs.Level3Code.forEachCount8_2 = gdjs.Level3Code.GDShape9Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount8_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape9Objects1);
gdjs.Level3Code.forEachCount9_2 = gdjs.Level3Code.GDShape10Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount9_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape10Objects1);
gdjs.Level3Code.forEachCount10_2 = gdjs.Level3Code.GDShape11Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount10_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape11Objects1);
for(gdjs.Level3Code.forEachIndex2 = 0;gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachTotalCount2;++gdjs.Level3Code.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects2);
gdjs.Level3Code.GDShape1Objects2.length = 0;

gdjs.Level3Code.GDShape10Objects2.length = 0;

gdjs.Level3Code.GDShape11Objects2.length = 0;

gdjs.Level3Code.GDShape2Objects2.length = 0;

gdjs.Level3Code.GDShape3Objects2.length = 0;

gdjs.Level3Code.GDShape4Objects2.length = 0;

gdjs.Level3Code.GDShape5Objects2.length = 0;

gdjs.Level3Code.GDShape6Objects2.length = 0;

gdjs.Level3Code.GDShape7Objects2.length = 0;

gdjs.Level3Code.GDShape8Objects2.length = 0;

gdjs.Level3Code.GDShape9Objects2.length = 0;


if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2) {
    gdjs.Level3Code.GDShape1Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2) {
    gdjs.Level3Code.GDShape2Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2+gdjs.Level3Code.forEachCount2_2) {
    gdjs.Level3Code.GDShape3Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2+gdjs.Level3Code.forEachCount2_2+gdjs.Level3Code.forEachCount3_2) {
    gdjs.Level3Code.GDShape4Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2+gdjs.Level3Code.forEachCount2_2+gdjs.Level3Code.forEachCount3_2+gdjs.Level3Code.forEachCount4_2) {
    gdjs.Level3Code.GDShape5Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2+gdjs.Level3Code.forEachCount2_2+gdjs.Level3Code.forEachCount3_2+gdjs.Level3Code.forEachCount4_2+gdjs.Level3Code.forEachCount5_2) {
    gdjs.Level3Code.GDShape6Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2+gdjs.Level3Code.forEachCount2_2+gdjs.Level3Code.forEachCount3_2+gdjs.Level3Code.forEachCount4_2+gdjs.Level3Code.forEachCount5_2+gdjs.Level3Code.forEachCount6_2) {
    gdjs.Level3Code.GDShape7Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2+gdjs.Level3Code.forEachCount2_2+gdjs.Level3Code.forEachCount3_2+gdjs.Level3Code.forEachCount4_2+gdjs.Level3Code.forEachCount5_2+gdjs.Level3Code.forEachCount6_2+gdjs.Level3Code.forEachCount7_2) {
    gdjs.Level3Code.GDShape8Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2+gdjs.Level3Code.forEachCount2_2+gdjs.Level3Code.forEachCount3_2+gdjs.Level3Code.forEachCount4_2+gdjs.Level3Code.forEachCount5_2+gdjs.Level3Code.forEachCount6_2+gdjs.Level3Code.forEachCount7_2+gdjs.Level3Code.forEachCount8_2) {
    gdjs.Level3Code.GDShape9Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2+gdjs.Level3Code.forEachCount2_2+gdjs.Level3Code.forEachCount3_2+gdjs.Level3Code.forEachCount4_2+gdjs.Level3Code.forEachCount5_2+gdjs.Level3Code.forEachCount6_2+gdjs.Level3Code.forEachCount7_2+gdjs.Level3Code.forEachCount8_2+gdjs.Level3Code.forEachCount9_2) {
    gdjs.Level3Code.GDShape10Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2+gdjs.Level3Code.forEachCount2_2+gdjs.Level3Code.forEachCount3_2+gdjs.Level3Code.forEachCount4_2+gdjs.Level3Code.forEachCount5_2+gdjs.Level3Code.forEachCount6_2+gdjs.Level3Code.forEachCount7_2+gdjs.Level3Code.forEachCount8_2+gdjs.Level3Code.forEachCount9_2+gdjs.Level3Code.forEachCount10_2) {
    gdjs.Level3Code.GDShape11Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape1Objects2Objects, gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects2Objects, false, runtimeScene, false);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.Level3Code.eventsList2(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shape2"), gdjs.Level3Code.GDShape2Objects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape2Objects1Objects, gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects1Objects, false, runtimeScene, false);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level3Code.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shape3"), gdjs.Level3Code.GDShape3Objects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape3Objects1Objects, gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects1Objects, false, runtimeScene, false);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level3Code.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shape4"), gdjs.Level3Code.GDShape4Objects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape4Objects1Objects, gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects1Objects, false, runtimeScene, false);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level3Code.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shape5"), gdjs.Level3Code.GDShape5Objects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape5Objects1Objects, gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects1Objects, false, runtimeScene, false);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level3Code.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shape6"), gdjs.Level3Code.GDShape6Objects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape6Objects1Objects, gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects1Objects, false, runtimeScene, false);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level3Code.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shape7"), gdjs.Level3Code.GDShape7Objects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape7Objects1Objects, gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects1Objects, false, runtimeScene, false);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level3Code.eventsList8(runtimeScene);} //End of subevents
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shape1"), gdjs.Level3Code.GDShape1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape10"), gdjs.Level3Code.GDShape10Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape11"), gdjs.Level3Code.GDShape11Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape2"), gdjs.Level3Code.GDShape2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape3"), gdjs.Level3Code.GDShape3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape4"), gdjs.Level3Code.GDShape4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape5"), gdjs.Level3Code.GDShape5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape6"), gdjs.Level3Code.GDShape6Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape7"), gdjs.Level3Code.GDShape7Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape8"), gdjs.Level3Code.GDShape8Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape9"), gdjs.Level3Code.GDShape9Objects1);

gdjs.Level3Code.forEachTotalCount2 = 0;
gdjs.Level3Code.forEachObjects2.length = 0;
gdjs.Level3Code.forEachCount0_2 = gdjs.Level3Code.GDShape1Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount0_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape1Objects1);
gdjs.Level3Code.forEachCount1_2 = gdjs.Level3Code.GDShape2Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount1_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape2Objects1);
gdjs.Level3Code.forEachCount2_2 = gdjs.Level3Code.GDShape3Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount2_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape3Objects1);
gdjs.Level3Code.forEachCount3_2 = gdjs.Level3Code.GDShape4Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount3_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape4Objects1);
gdjs.Level3Code.forEachCount4_2 = gdjs.Level3Code.GDShape5Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount4_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape5Objects1);
gdjs.Level3Code.forEachCount5_2 = gdjs.Level3Code.GDShape6Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount5_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape6Objects1);
gdjs.Level3Code.forEachCount6_2 = gdjs.Level3Code.GDShape7Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount6_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape7Objects1);
gdjs.Level3Code.forEachCount7_2 = gdjs.Level3Code.GDShape8Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount7_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape8Objects1);
gdjs.Level3Code.forEachCount8_2 = gdjs.Level3Code.GDShape9Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount8_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape9Objects1);
gdjs.Level3Code.forEachCount9_2 = gdjs.Level3Code.GDShape10Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount9_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape10Objects1);
gdjs.Level3Code.forEachCount10_2 = gdjs.Level3Code.GDShape11Objects1.length;
gdjs.Level3Code.forEachTotalCount2 += gdjs.Level3Code.forEachCount10_2;
gdjs.Level3Code.forEachObjects2.push.apply(gdjs.Level3Code.forEachObjects2,gdjs.Level3Code.GDShape11Objects1);
for(gdjs.Level3Code.forEachIndex2 = 0;gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachTotalCount2;++gdjs.Level3Code.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects2);
gdjs.Level3Code.GDShape1Objects2.length = 0;

gdjs.Level3Code.GDShape10Objects2.length = 0;

gdjs.Level3Code.GDShape11Objects2.length = 0;

gdjs.Level3Code.GDShape2Objects2.length = 0;

gdjs.Level3Code.GDShape3Objects2.length = 0;

gdjs.Level3Code.GDShape4Objects2.length = 0;

gdjs.Level3Code.GDShape5Objects2.length = 0;

gdjs.Level3Code.GDShape6Objects2.length = 0;

gdjs.Level3Code.GDShape7Objects2.length = 0;

gdjs.Level3Code.GDShape8Objects2.length = 0;

gdjs.Level3Code.GDShape9Objects2.length = 0;


if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2) {
    gdjs.Level3Code.GDShape1Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2) {
    gdjs.Level3Code.GDShape2Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2+gdjs.Level3Code.forEachCount2_2) {
    gdjs.Level3Code.GDShape3Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2+gdjs.Level3Code.forEachCount2_2+gdjs.Level3Code.forEachCount3_2) {
    gdjs.Level3Code.GDShape4Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2+gdjs.Level3Code.forEachCount2_2+gdjs.Level3Code.forEachCount3_2+gdjs.Level3Code.forEachCount4_2) {
    gdjs.Level3Code.GDShape5Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2+gdjs.Level3Code.forEachCount2_2+gdjs.Level3Code.forEachCount3_2+gdjs.Level3Code.forEachCount4_2+gdjs.Level3Code.forEachCount5_2) {
    gdjs.Level3Code.GDShape6Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2+gdjs.Level3Code.forEachCount2_2+gdjs.Level3Code.forEachCount3_2+gdjs.Level3Code.forEachCount4_2+gdjs.Level3Code.forEachCount5_2+gdjs.Level3Code.forEachCount6_2) {
    gdjs.Level3Code.GDShape7Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2+gdjs.Level3Code.forEachCount2_2+gdjs.Level3Code.forEachCount3_2+gdjs.Level3Code.forEachCount4_2+gdjs.Level3Code.forEachCount5_2+gdjs.Level3Code.forEachCount6_2+gdjs.Level3Code.forEachCount7_2) {
    gdjs.Level3Code.GDShape8Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2+gdjs.Level3Code.forEachCount2_2+gdjs.Level3Code.forEachCount3_2+gdjs.Level3Code.forEachCount4_2+gdjs.Level3Code.forEachCount5_2+gdjs.Level3Code.forEachCount6_2+gdjs.Level3Code.forEachCount7_2+gdjs.Level3Code.forEachCount8_2) {
    gdjs.Level3Code.GDShape9Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2+gdjs.Level3Code.forEachCount2_2+gdjs.Level3Code.forEachCount3_2+gdjs.Level3Code.forEachCount4_2+gdjs.Level3Code.forEachCount5_2+gdjs.Level3Code.forEachCount6_2+gdjs.Level3Code.forEachCount7_2+gdjs.Level3Code.forEachCount8_2+gdjs.Level3Code.forEachCount9_2) {
    gdjs.Level3Code.GDShape10Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
else if (gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.forEachCount0_2+gdjs.Level3Code.forEachCount1_2+gdjs.Level3Code.forEachCount2_2+gdjs.Level3Code.forEachCount3_2+gdjs.Level3Code.forEachCount4_2+gdjs.Level3Code.forEachCount5_2+gdjs.Level3Code.forEachCount6_2+gdjs.Level3Code.forEachCount7_2+gdjs.Level3Code.forEachCount8_2+gdjs.Level3Code.forEachCount9_2+gdjs.Level3Code.forEachCount10_2) {
    gdjs.Level3Code.GDShape11Objects2.push(gdjs.Level3Code.forEachObjects2[gdjs.Level3Code.forEachIndex2]);
}
gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape8Objects2Objects, gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects2Objects, false, runtimeScene, false);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.Level3Code.eventsList9(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shape9"), gdjs.Level3Code.GDShape9Objects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape9Objects1Objects, gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects1Objects, false, runtimeScene, false);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level3Code.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shape10"), gdjs.Level3Code.GDShape10Objects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape10Objects1Objects, gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects1Objects, false, runtimeScene, false);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level3Code.eventsList11(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shape11"), gdjs.Level3Code.GDShape11Objects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDShape11Objects1Objects, gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects1Objects, false, runtimeScene, false);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level3Code.eventsList12(runtimeScene);} //End of subevents
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Obstacle"), gdjs.Level3Code.GDObstacleObjects1);

for(gdjs.Level3Code.forEachIndex2 = 0;gdjs.Level3Code.forEachIndex2 < gdjs.Level3Code.GDObstacleObjects1.length;++gdjs.Level3Code.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects2);
gdjs.Level3Code.GDObstacleObjects2.length = 0;


gdjs.Level3Code.forEachTemporary2 = gdjs.Level3Code.GDObstacleObjects1[gdjs.Level3Code.forEachIndex2];
gdjs.Level3Code.GDObstacleObjects2.push(gdjs.Level3Code.forEachTemporary2);
gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDObstacleObjects2Objects, gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayer1Objects2Objects, false, runtimeScene, false);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.Level3Code.GDObstacleObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDObstacleObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level3Code.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.Level3Code.GDplayer1Objects2[i].getBehavior("Health").Hit(1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Damage1L.mp3", false, 100, 1);
}}
}

}


{



}


{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 5, "ObstacleCreation");
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
gdjs.Level3Code.GDObstacleObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDObstacleObjects1Objects, gdjs.randomInRange(80, 640 - 80), 950, "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ObstacleCreation");
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Obstacle"), gdjs.Level3Code.GDObstacleObjects1);
{for(var i = 0, len = gdjs.Level3Code.GDObstacleObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDObstacleObjects1[i].addPolarForce(270, 0.5 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
}{for(var i = 0, len = gdjs.Level3Code.GDObstacleObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDObstacleObjects1[i].setZOrder(4);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level3Code.GDplayer1Objects1.length;i<l;++i) {
    if ( gdjs.Level3Code.GDplayer1Objects1[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level3Code.condition0IsTrue_0.val = true;
        gdjs.Level3Code.GDplayer1Objects1[k] = gdjs.Level3Code.GDplayer1Objects1[i];
        ++k;
    }
}
gdjs.Level3Code.GDplayer1Objects1.length = k;}if (gdjs.Level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Life"), gdjs.Level3Code.GDLifeObjects1);
/* Reuse gdjs.Level3Code.GDplayer1Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDLifeObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDLifeObjects1[i].setAnimationName("Life" + gdjs.evtTools.common.toString((( gdjs.Level3Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.Level3Code.GDplayer1Objects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))));
}
}{for(var i = 0, len = gdjs.Level3Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDplayer1Objects1[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.Level3Code.GDplayer1Objects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level3Code.GDplayer1Objects1.length;i<l;++i) {
    if ( gdjs.Level3Code.GDplayer1Objects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level3Code.condition0IsTrue_0.val = true;
        gdjs.Level3Code.GDplayer1Objects1[k] = gdjs.Level3Code.GDplayer1Objects1[i];
        ++k;
    }
}
gdjs.Level3Code.GDplayer1Objects1.length = k;}if (gdjs.Level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ButtonMainMenu"), gdjs.Level3Code.GDButtonMainMenuObjects1);
gdjs.copyArray(runtimeScene.getObjects("ButtonTryAgain"), gdjs.Level3Code.GDButtonTryAgainObjects1);
gdjs.copyArray(runtimeScene.getObjects("GameOver"), gdjs.Level3Code.GDGameOverObjects1);
gdjs.copyArray(runtimeScene.getObjects("Life"), gdjs.Level3Code.GDLifeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Obstacle"), gdjs.Level3Code.GDObstacleObjects1);
gdjs.copyArray(runtimeScene.getObjects("Shape1"), gdjs.Level3Code.GDShape1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape10"), gdjs.Level3Code.GDShape10Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape11"), gdjs.Level3Code.GDShape11Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape2"), gdjs.Level3Code.GDShape2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape3"), gdjs.Level3Code.GDShape3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape4"), gdjs.Level3Code.GDShape4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape5"), gdjs.Level3Code.GDShape5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape6"), gdjs.Level3Code.GDShape6Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape7"), gdjs.Level3Code.GDShape7Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape8"), gdjs.Level3Code.GDShape8Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape9"), gdjs.Level3Code.GDShape9Objects1);
/* Reuse gdjs.Level3Code.GDplayer1Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDLifeObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDLifeObjects1[i].setAnimationName("Life0");
}
}{for(var i = 0, len = gdjs.Level3Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDplayer1Objects1[i].setAnimationName("player_dead");
}
}{for(var i = 0, len = gdjs.Level3Code.GDShape1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape1Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level3Code.GDShape2Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape2Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level3Code.GDShape3Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape3Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level3Code.GDShape4Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape4Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level3Code.GDShape5Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape5Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level3Code.GDShape6Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape6Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level3Code.GDShape7Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape7Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level3Code.GDShape8Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape8Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level3Code.GDShape9Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape9Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level3Code.GDShape10Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape10Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level3Code.GDShape11Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDShape11Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level3Code.GDObstacleObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDObstacleObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level3Code.GDGameOverObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDGameOverObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level3Code.GDButtonTryAgainObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDButtonTryAgainObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level3Code.GDButtonMainMenuObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDButtonMainMenuObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.Level3Code.eventsList18(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ButtonMainMenu"), gdjs.Level3Code.GDButtonMainMenuObjects1);
gdjs.copyArray(runtimeScene.getObjects("ButtonTryAgain"), gdjs.Level3Code.GDButtonTryAgainObjects1);
gdjs.copyArray(runtimeScene.getObjects("GameOver"), gdjs.Level3Code.GDGameOverObjects1);
{for(var i = 0, len = gdjs.Level3Code.GDGameOverObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDGameOverObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level3Code.GDButtonTryAgainObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDButtonTryAgainObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level3Code.GDButtonMainMenuObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDButtonMainMenuObjects1[i].hide();
}
}}

}


{



}


{


{
{runtimeScene.getScene().getVariables().getFromIndex(0).add(7 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}}

}


{


{
}

}


{


gdjs.Level3Code.eventsList19(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Pause"), gdjs.Level3Code.GDPauseObjects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDPauseObjects1Objects, runtimeScene, true, true);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDPauseObjects1 */
{for(var i = 0, len = gdjs.Level3Code.GDPauseObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDPauseObjects1[i].setAnimationName("StartNormal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Pause"), gdjs.Level3Code.GDPauseObjects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDPauseObjects1Objects, runtimeScene, true, false);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDPauseObjects1 */
{for(var i = 0, len = gdjs.Level3Code.GDPauseObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDPauseObjects1[i].setAnimationName("StartHover");
}
}
{ //Subevents
gdjs.Level3Code.eventsList21(runtimeScene);} //End of subevents
}

}


{


{
}

}


{


gdjs.Level3Code.eventsList22(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("MainMenu2"), gdjs.Level3Code.GDMainMenu2Objects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDMainMenu2Objects1Objects, runtimeScene, true, true);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDMainMenu2Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDMainMenu2Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDMainMenu2Objects1[i].setAnimationName("StartNormal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("MainMenu2"), gdjs.Level3Code.GDMainMenu2Objects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDMainMenu2Objects1Objects, runtimeScene, true, false);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDMainMenu2Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDMainMenu2Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDMainMenu2Objects1[i].setAnimationName("StartHover");
}
}
{ //Subevents
gdjs.Level3Code.eventsList24(runtimeScene);} //End of subevents
}

}


{


{
}

}


{


{
}

}


{


gdjs.Level3Code.eventsList25(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Right1"), gdjs.Level3Code.GDRight1Objects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDRight1Objects1Objects, runtimeScene, true, true);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDRight1Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDRight1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDRight1Objects1[i].setAnimationName("StartNormal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Right1"), gdjs.Level3Code.GDRight1Objects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDRight1Objects1Objects, runtimeScene, true, false);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDRight1Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDRight1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDRight1Objects1[i].setAnimationName("StartHover");
}
}
{ //Subevents
gdjs.Level3Code.eventsList27(runtimeScene);} //End of subevents
}

}


{


{
}

}


{


{
}

}


{


gdjs.Level3Code.eventsList28(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Left1"), gdjs.Level3Code.GDLeft1Objects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDLeft1Objects1Objects, runtimeScene, true, true);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDLeft1Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDLeft1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDLeft1Objects1[i].setAnimationName("StartNormal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Left1"), gdjs.Level3Code.GDLeft1Objects1);

gdjs.Level3Code.condition0IsTrue_0.val = false;
{
gdjs.Level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDLeft1Objects1Objects, runtimeScene, true, false);
}if (gdjs.Level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level3Code.GDLeft1Objects1 */
{for(var i = 0, len = gdjs.Level3Code.GDLeft1Objects1.length ;i < len;++i) {
    gdjs.Level3Code.GDLeft1Objects1[i].setAnimationName("StartHover");
}
}
{ //Subevents
gdjs.Level3Code.eventsList30(runtimeScene);} //End of subevents
}

}


{


{
}

}


};

gdjs.Level3Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level3Code.GDBorder1Objects1.length = 0;
gdjs.Level3Code.GDBorder1Objects2.length = 0;
gdjs.Level3Code.GDBorder1Objects3.length = 0;
gdjs.Level3Code.GDBorder1Objects4.length = 0;
gdjs.Level3Code.GDb1Objects1.length = 0;
gdjs.Level3Code.GDb1Objects2.length = 0;
gdjs.Level3Code.GDb1Objects3.length = 0;
gdjs.Level3Code.GDb1Objects4.length = 0;
gdjs.Level3Code.GDShape1Objects1.length = 0;
gdjs.Level3Code.GDShape1Objects2.length = 0;
gdjs.Level3Code.GDShape1Objects3.length = 0;
gdjs.Level3Code.GDShape1Objects4.length = 0;
gdjs.Level3Code.GDShape8Objects1.length = 0;
gdjs.Level3Code.GDShape8Objects2.length = 0;
gdjs.Level3Code.GDShape8Objects3.length = 0;
gdjs.Level3Code.GDShape8Objects4.length = 0;
gdjs.Level3Code.GDShape2Objects1.length = 0;
gdjs.Level3Code.GDShape2Objects2.length = 0;
gdjs.Level3Code.GDShape2Objects3.length = 0;
gdjs.Level3Code.GDShape2Objects4.length = 0;
gdjs.Level3Code.GDShape9Objects1.length = 0;
gdjs.Level3Code.GDShape9Objects2.length = 0;
gdjs.Level3Code.GDShape9Objects3.length = 0;
gdjs.Level3Code.GDShape9Objects4.length = 0;
gdjs.Level3Code.GDShape3Objects1.length = 0;
gdjs.Level3Code.GDShape3Objects2.length = 0;
gdjs.Level3Code.GDShape3Objects3.length = 0;
gdjs.Level3Code.GDShape3Objects4.length = 0;
gdjs.Level3Code.GDShape10Objects1.length = 0;
gdjs.Level3Code.GDShape10Objects2.length = 0;
gdjs.Level3Code.GDShape10Objects3.length = 0;
gdjs.Level3Code.GDShape10Objects4.length = 0;
gdjs.Level3Code.GDShape4Objects1.length = 0;
gdjs.Level3Code.GDShape4Objects2.length = 0;
gdjs.Level3Code.GDShape4Objects3.length = 0;
gdjs.Level3Code.GDShape4Objects4.length = 0;
gdjs.Level3Code.GDShape11Objects1.length = 0;
gdjs.Level3Code.GDShape11Objects2.length = 0;
gdjs.Level3Code.GDShape11Objects3.length = 0;
gdjs.Level3Code.GDShape11Objects4.length = 0;
gdjs.Level3Code.GDShape5Objects1.length = 0;
gdjs.Level3Code.GDShape5Objects2.length = 0;
gdjs.Level3Code.GDShape5Objects3.length = 0;
gdjs.Level3Code.GDShape5Objects4.length = 0;
gdjs.Level3Code.GDShape6Objects1.length = 0;
gdjs.Level3Code.GDShape6Objects2.length = 0;
gdjs.Level3Code.GDShape6Objects3.length = 0;
gdjs.Level3Code.GDShape6Objects4.length = 0;
gdjs.Level3Code.GDShape7Objects1.length = 0;
gdjs.Level3Code.GDShape7Objects2.length = 0;
gdjs.Level3Code.GDShape7Objects3.length = 0;
gdjs.Level3Code.GDShape7Objects4.length = 0;
gdjs.Level3Code.GDScoreObjects1.length = 0;
gdjs.Level3Code.GDScoreObjects2.length = 0;
gdjs.Level3Code.GDScoreObjects3.length = 0;
gdjs.Level3Code.GDScoreObjects4.length = 0;
gdjs.Level3Code.GDObstacleObjects1.length = 0;
gdjs.Level3Code.GDObstacleObjects2.length = 0;
gdjs.Level3Code.GDObstacleObjects3.length = 0;
gdjs.Level3Code.GDObstacleObjects4.length = 0;
gdjs.Level3Code.GDLifeObjects1.length = 0;
gdjs.Level3Code.GDLifeObjects2.length = 0;
gdjs.Level3Code.GDLifeObjects3.length = 0;
gdjs.Level3Code.GDLifeObjects4.length = 0;
gdjs.Level3Code.GDGameOverObjects1.length = 0;
gdjs.Level3Code.GDGameOverObjects2.length = 0;
gdjs.Level3Code.GDGameOverObjects3.length = 0;
gdjs.Level3Code.GDGameOverObjects4.length = 0;
gdjs.Level3Code.GDButtonTryAgainObjects1.length = 0;
gdjs.Level3Code.GDButtonTryAgainObjects2.length = 0;
gdjs.Level3Code.GDButtonTryAgainObjects3.length = 0;
gdjs.Level3Code.GDButtonTryAgainObjects4.length = 0;
gdjs.Level3Code.GDShape7ExplosionObjects1.length = 0;
gdjs.Level3Code.GDShape7ExplosionObjects2.length = 0;
gdjs.Level3Code.GDShape7ExplosionObjects3.length = 0;
gdjs.Level3Code.GDShape7ExplosionObjects4.length = 0;
gdjs.Level3Code.GDShape6ExplosionObjects1.length = 0;
gdjs.Level3Code.GDShape6ExplosionObjects2.length = 0;
gdjs.Level3Code.GDShape6ExplosionObjects3.length = 0;
gdjs.Level3Code.GDShape6ExplosionObjects4.length = 0;
gdjs.Level3Code.GDShape5ExplosionObjects1.length = 0;
gdjs.Level3Code.GDShape5ExplosionObjects2.length = 0;
gdjs.Level3Code.GDShape5ExplosionObjects3.length = 0;
gdjs.Level3Code.GDShape5ExplosionObjects4.length = 0;
gdjs.Level3Code.GDShape4ExplosionObjects1.length = 0;
gdjs.Level3Code.GDShape4ExplosionObjects2.length = 0;
gdjs.Level3Code.GDShape4ExplosionObjects3.length = 0;
gdjs.Level3Code.GDShape4ExplosionObjects4.length = 0;
gdjs.Level3Code.GDShape11ExplosionObjects1.length = 0;
gdjs.Level3Code.GDShape11ExplosionObjects2.length = 0;
gdjs.Level3Code.GDShape11ExplosionObjects3.length = 0;
gdjs.Level3Code.GDShape11ExplosionObjects4.length = 0;
gdjs.Level3Code.GDShape3ExplosionObjects1.length = 0;
gdjs.Level3Code.GDShape3ExplosionObjects2.length = 0;
gdjs.Level3Code.GDShape3ExplosionObjects3.length = 0;
gdjs.Level3Code.GDShape3ExplosionObjects4.length = 0;
gdjs.Level3Code.GDShape10ExplosionObjects1.length = 0;
gdjs.Level3Code.GDShape10ExplosionObjects2.length = 0;
gdjs.Level3Code.GDShape10ExplosionObjects3.length = 0;
gdjs.Level3Code.GDShape10ExplosionObjects4.length = 0;
gdjs.Level3Code.GDShape2ExplosionObjects1.length = 0;
gdjs.Level3Code.GDShape2ExplosionObjects2.length = 0;
gdjs.Level3Code.GDShape2ExplosionObjects3.length = 0;
gdjs.Level3Code.GDShape2ExplosionObjects4.length = 0;
gdjs.Level3Code.GDShape9ExplosionObjects1.length = 0;
gdjs.Level3Code.GDShape9ExplosionObjects2.length = 0;
gdjs.Level3Code.GDShape9ExplosionObjects3.length = 0;
gdjs.Level3Code.GDShape9ExplosionObjects4.length = 0;
gdjs.Level3Code.GDShape1ExplosionObjects1.length = 0;
gdjs.Level3Code.GDShape1ExplosionObjects2.length = 0;
gdjs.Level3Code.GDShape1ExplosionObjects3.length = 0;
gdjs.Level3Code.GDShape1ExplosionObjects4.length = 0;
gdjs.Level3Code.GDShape8ExplosionObjects1.length = 0;
gdjs.Level3Code.GDShape8ExplosionObjects2.length = 0;
gdjs.Level3Code.GDShape8ExplosionObjects3.length = 0;
gdjs.Level3Code.GDShape8ExplosionObjects4.length = 0;
gdjs.Level3Code.GDButtonMainMenuObjects1.length = 0;
gdjs.Level3Code.GDButtonMainMenuObjects2.length = 0;
gdjs.Level3Code.GDButtonMainMenuObjects3.length = 0;
gdjs.Level3Code.GDButtonMainMenuObjects4.length = 0;
gdjs.Level3Code.GDPauseObjects1.length = 0;
gdjs.Level3Code.GDPauseObjects2.length = 0;
gdjs.Level3Code.GDPauseObjects3.length = 0;
gdjs.Level3Code.GDPauseObjects4.length = 0;
gdjs.Level3Code.GDplayer1Objects1.length = 0;
gdjs.Level3Code.GDplayer1Objects2.length = 0;
gdjs.Level3Code.GDplayer1Objects3.length = 0;
gdjs.Level3Code.GDplayer1Objects4.length = 0;
gdjs.Level3Code.GDNewTextObjects1.length = 0;
gdjs.Level3Code.GDNewTextObjects2.length = 0;
gdjs.Level3Code.GDNewTextObjects3.length = 0;
gdjs.Level3Code.GDNewTextObjects4.length = 0;
gdjs.Level3Code.GDRight1Objects1.length = 0;
gdjs.Level3Code.GDRight1Objects2.length = 0;
gdjs.Level3Code.GDRight1Objects3.length = 0;
gdjs.Level3Code.GDRight1Objects4.length = 0;
gdjs.Level3Code.GDLeft1Objects1.length = 0;
gdjs.Level3Code.GDLeft1Objects2.length = 0;
gdjs.Level3Code.GDLeft1Objects3.length = 0;
gdjs.Level3Code.GDLeft1Objects4.length = 0;
gdjs.Level3Code.GDBGS1Objects1.length = 0;
gdjs.Level3Code.GDBGS1Objects2.length = 0;
gdjs.Level3Code.GDBGS1Objects3.length = 0;
gdjs.Level3Code.GDBGS1Objects4.length = 0;
gdjs.Level3Code.GDMainMenu2Objects1.length = 0;
gdjs.Level3Code.GDMainMenu2Objects2.length = 0;
gdjs.Level3Code.GDMainMenu2Objects3.length = 0;
gdjs.Level3Code.GDMainMenu2Objects4.length = 0;
gdjs.Level3Code.GDEarth1Objects1.length = 0;
gdjs.Level3Code.GDEarth1Objects2.length = 0;
gdjs.Level3Code.GDEarth1Objects3.length = 0;
gdjs.Level3Code.GDEarth1Objects4.length = 0;

gdjs.Level3Code.eventsList31(runtimeScene);

return;

}

gdjs['Level3Code'] = gdjs.Level3Code;
