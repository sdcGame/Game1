gdjs.Level2Code = {};
gdjs.Level2Code.forEachCount0_2 = 0;

gdjs.Level2Code.forEachCount1_2 = 0;

gdjs.Level2Code.forEachCount2_2 = 0;

gdjs.Level2Code.forEachCount3_2 = 0;

gdjs.Level2Code.forEachIndex2 = 0;

gdjs.Level2Code.forEachObjects2 = [];

gdjs.Level2Code.forEachTemporary2 = null;

gdjs.Level2Code.forEachTotalCount2 = 0;

gdjs.Level2Code.GDEarthObjects1= [];
gdjs.Level2Code.GDEarthObjects2= [];
gdjs.Level2Code.GDEarthObjects3= [];
gdjs.Level2Code.GDEarthObjects4= [];
gdjs.Level2Code.GDPauseObjects1= [];
gdjs.Level2Code.GDPauseObjects2= [];
gdjs.Level2Code.GDPauseObjects3= [];
gdjs.Level2Code.GDPauseObjects4= [];
gdjs.Level2Code.GDkenneyObjects1= [];
gdjs.Level2Code.GDkenneyObjects2= [];
gdjs.Level2Code.GDkenneyObjects3= [];
gdjs.Level2Code.GDkenneyObjects4= [];
gdjs.Level2Code.GDbulletObjects1= [];
gdjs.Level2Code.GDbulletObjects2= [];
gdjs.Level2Code.GDbulletObjects3= [];
gdjs.Level2Code.GDbulletObjects4= [];
gdjs.Level2Code.GDShape1Objects1= [];
gdjs.Level2Code.GDShape1Objects2= [];
gdjs.Level2Code.GDShape1Objects3= [];
gdjs.Level2Code.GDShape1Objects4= [];
gdjs.Level2Code.GDShape2Objects1= [];
gdjs.Level2Code.GDShape2Objects2= [];
gdjs.Level2Code.GDShape2Objects3= [];
gdjs.Level2Code.GDShape2Objects4= [];
gdjs.Level2Code.GDShape3Objects1= [];
gdjs.Level2Code.GDShape3Objects2= [];
gdjs.Level2Code.GDShape3Objects3= [];
gdjs.Level2Code.GDShape3Objects4= [];
gdjs.Level2Code.GDShape4Objects1= [];
gdjs.Level2Code.GDShape4Objects2= [];
gdjs.Level2Code.GDShape4Objects3= [];
gdjs.Level2Code.GDShape4Objects4= [];
gdjs.Level2Code.GDScoreObjects1= [];
gdjs.Level2Code.GDScoreObjects2= [];
gdjs.Level2Code.GDScoreObjects3= [];
gdjs.Level2Code.GDScoreObjects4= [];
gdjs.Level2Code.GDObstacleObjects1= [];
gdjs.Level2Code.GDObstacleObjects2= [];
gdjs.Level2Code.GDObstacleObjects3= [];
gdjs.Level2Code.GDObstacleObjects4= [];
gdjs.Level2Code.GDLifeObjects1= [];
gdjs.Level2Code.GDLifeObjects2= [];
gdjs.Level2Code.GDLifeObjects3= [];
gdjs.Level2Code.GDLifeObjects4= [];
gdjs.Level2Code.GDButtonTryAgainObjects1= [];
gdjs.Level2Code.GDButtonTryAgainObjects2= [];
gdjs.Level2Code.GDButtonTryAgainObjects3= [];
gdjs.Level2Code.GDButtonTryAgainObjects4= [];
gdjs.Level2Code.GDButtonMainMenuObjects1= [];
gdjs.Level2Code.GDButtonMainMenuObjects2= [];
gdjs.Level2Code.GDButtonMainMenuObjects3= [];
gdjs.Level2Code.GDButtonMainMenuObjects4= [];
gdjs.Level2Code.GDShape4ExplosionObjects1= [];
gdjs.Level2Code.GDShape4ExplosionObjects2= [];
gdjs.Level2Code.GDShape4ExplosionObjects3= [];
gdjs.Level2Code.GDShape4ExplosionObjects4= [];
gdjs.Level2Code.GDShape3ExplosionObjects1= [];
gdjs.Level2Code.GDShape3ExplosionObjects2= [];
gdjs.Level2Code.GDShape3ExplosionObjects3= [];
gdjs.Level2Code.GDShape3ExplosionObjects4= [];
gdjs.Level2Code.GDShape2ExplosionObjects1= [];
gdjs.Level2Code.GDShape2ExplosionObjects2= [];
gdjs.Level2Code.GDShape2ExplosionObjects3= [];
gdjs.Level2Code.GDShape2ExplosionObjects4= [];
gdjs.Level2Code.GDShape1ExplosionObjects1= [];
gdjs.Level2Code.GDShape1ExplosionObjects2= [];
gdjs.Level2Code.GDShape1ExplosionObjects3= [];
gdjs.Level2Code.GDShape1ExplosionObjects4= [];
gdjs.Level2Code.GDEarth1Objects1= [];
gdjs.Level2Code.GDEarth1Objects2= [];
gdjs.Level2Code.GDEarth1Objects3= [];
gdjs.Level2Code.GDEarth1Objects4= [];
gdjs.Level2Code.GDLifetextObjects1= [];
gdjs.Level2Code.GDLifetextObjects2= [];
gdjs.Level2Code.GDLifetextObjects3= [];
gdjs.Level2Code.GDLifetextObjects4= [];
gdjs.Level2Code.GDRed1Objects1= [];
gdjs.Level2Code.GDRed1Objects2= [];
gdjs.Level2Code.GDRed1Objects3= [];
gdjs.Level2Code.GDRed1Objects4= [];
gdjs.Level2Code.GDMainmenu2Objects1= [];
gdjs.Level2Code.GDMainmenu2Objects2= [];
gdjs.Level2Code.GDMainmenu2Objects3= [];
gdjs.Level2Code.GDMainmenu2Objects4= [];
gdjs.Level2Code.GDGameoverObjects1= [];
gdjs.Level2Code.GDGameoverObjects2= [];
gdjs.Level2Code.GDGameoverObjects3= [];
gdjs.Level2Code.GDGameoverObjects4= [];
gdjs.Level2Code.GDBlack1Objects1= [];
gdjs.Level2Code.GDBlack1Objects2= [];
gdjs.Level2Code.GDBlack1Objects3= [];
gdjs.Level2Code.GDBlack1Objects4= [];
gdjs.Level2Code.GDScreen_95borderObjects1= [];
gdjs.Level2Code.GDScreen_95borderObjects2= [];
gdjs.Level2Code.GDScreen_95borderObjects3= [];
gdjs.Level2Code.GDScreen_95borderObjects4= [];
gdjs.Level2Code.GDBGS1Objects1= [];
gdjs.Level2Code.GDBGS1Objects2= [];
gdjs.Level2Code.GDBGS1Objects3= [];
gdjs.Level2Code.GDBGS1Objects4= [];

gdjs.Level2Code.conditionTrue_0 = {val:false};
gdjs.Level2Code.condition0IsTrue_0 = {val:false};
gdjs.Level2Code.condition1IsTrue_0 = {val:false};
gdjs.Level2Code.condition2IsTrue_0 = {val:false};
gdjs.Level2Code.conditionTrue_1 = {val:false};
gdjs.Level2Code.condition0IsTrue_1 = {val:false};
gdjs.Level2Code.condition1IsTrue_1 = {val:false};
gdjs.Level2Code.condition2IsTrue_1 = {val:false};


gdjs.Level2Code.eventsList0 = function(runtimeScene) {

};gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape1Objects1ObjectsGDgdjs_46Level2Code_46GDShape2Objects1ObjectsGDgdjs_46Level2Code_46GDShape3Objects1ObjectsGDgdjs_46Level2Code_46GDShape4Objects1Objects = Hashtable.newFrom({"Shape1": gdjs.Level2Code.GDShape1Objects1, "Shape2": gdjs.Level2Code.GDShape2Objects1, "Shape3": gdjs.Level2Code.GDShape3Objects1, "Shape4": gdjs.Level2Code.GDShape4Objects1});
gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape1Objects2ObjectsGDgdjs_46Level2Code_46GDShape2Objects2ObjectsGDgdjs_46Level2Code_46GDShape3Objects2ObjectsGDgdjs_46Level2Code_46GDShape4Objects2Objects = Hashtable.newFrom({"Shape1": gdjs.Level2Code.GDShape1Objects2, "Shape2": gdjs.Level2Code.GDShape2Objects2, "Shape3": gdjs.Level2Code.GDShape3Objects2, "Shape4": gdjs.Level2Code.GDShape4Objects2});
gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDbulletObjects2Objects = Hashtable.newFrom({"bullet": gdjs.Level2Code.GDbulletObjects2});
gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape1Objects3Objects = Hashtable.newFrom({"Shape1": gdjs.Level2Code.GDShape1Objects3});
gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape1ExplosionObjects3Objects = Hashtable.newFrom({"Shape1Explosion": gdjs.Level2Code.GDShape1ExplosionObjects3});
gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape2Objects3Objects = Hashtable.newFrom({"Shape2": gdjs.Level2Code.GDShape2Objects3});
gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape2ExplosionObjects3Objects = Hashtable.newFrom({"Shape2Explosion": gdjs.Level2Code.GDShape2ExplosionObjects3});
gdjs.Level2Code.eventsList1 = function(runtimeScene) {

{


{
}

}


};gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape3Objects3Objects = Hashtable.newFrom({"Shape3": gdjs.Level2Code.GDShape3Objects3});
gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape3ExplosionObjects3Objects = Hashtable.newFrom({"Shape3Explosion": gdjs.Level2Code.GDShape3ExplosionObjects3});
gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape4Objects3Objects = Hashtable.newFrom({"Shape4": gdjs.Level2Code.GDShape4Objects3});
gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape4ExplosionObjects3Objects = Hashtable.newFrom({"Shape4Explosion": gdjs.Level2Code.GDShape4ExplosionObjects3});
gdjs.Level2Code.eventsList2 = function(runtimeScene) {

{


{
}

}


};gdjs.Level2Code.eventsList3 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.Level2Code.GDShape1Objects2, gdjs.Level2Code.GDShape1Objects3);


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape1Objects3Objects) != 0;
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level2Code.GDShape1Objects3 */
gdjs.Level2Code.GDShape1ExplosionObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape1ExplosionObjects3Objects, (( gdjs.Level2Code.GDShape1Objects3.length === 0 ) ? 0 :gdjs.Level2Code.GDShape1Objects3[0].getPointX("Center")), (( gdjs.Level2Code.GDShape1Objects3.length === 0 ) ? 0 :gdjs.Level2Code.GDShape1Objects3[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.Level2Code.GDShape1ExplosionObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDShape1ExplosionObjects3[i].setParticleSize1((( gdjs.Level2Code.GDShape1Objects3.length === 0 ) ? 0 :gdjs.Level2Code.GDShape1Objects3[0].getWidth()));
}
}}

}


{

gdjs.copyArray(gdjs.Level2Code.GDShape2Objects2, gdjs.Level2Code.GDShape2Objects3);


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape2Objects3Objects) != 0;
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level2Code.GDShape2Objects3 */
gdjs.Level2Code.GDShape2ExplosionObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape2ExplosionObjects3Objects, (( gdjs.Level2Code.GDShape2Objects3.length === 0 ) ? 0 :gdjs.Level2Code.GDShape2Objects3[0].getPointX("Center")), (( gdjs.Level2Code.GDShape2Objects3.length === 0 ) ? 0 :gdjs.Level2Code.GDShape2Objects3[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.Level2Code.GDShape2ExplosionObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDShape2ExplosionObjects3[i].setParticleSize1((( gdjs.Level2Code.GDShape2Objects3.length === 0 ) ? 0 :gdjs.Level2Code.GDShape2Objects3[0].getWidth()));
}
}
{ //Subevents
gdjs.Level2Code.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Level2Code.GDShape3Objects2, gdjs.Level2Code.GDShape3Objects3);


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape3Objects3Objects) != 0;
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level2Code.GDShape3Objects3 */
gdjs.Level2Code.GDShape3ExplosionObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape3ExplosionObjects3Objects, (( gdjs.Level2Code.GDShape3Objects3.length === 0 ) ? 0 :gdjs.Level2Code.GDShape3Objects3[0].getPointX("Center")), (( gdjs.Level2Code.GDShape3Objects3.length === 0 ) ? 0 :gdjs.Level2Code.GDShape3Objects3[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.Level2Code.GDShape3ExplosionObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDShape3ExplosionObjects3[i].setParticleSize1((( gdjs.Level2Code.GDShape3Objects3.length === 0 ) ? 0 :gdjs.Level2Code.GDShape3Objects3[0].getWidth()));
}
}}

}


{

gdjs.copyArray(gdjs.Level2Code.GDShape4Objects2, gdjs.Level2Code.GDShape4Objects3);


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape4Objects3Objects) != 0;
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level2Code.GDShape4Objects3 */
gdjs.Level2Code.GDShape4ExplosionObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape4ExplosionObjects3Objects, (( gdjs.Level2Code.GDShape4Objects3.length === 0 ) ? 0 :gdjs.Level2Code.GDShape4Objects3[0].getPointX("Center")), (( gdjs.Level2Code.GDShape4Objects3.length === 0 ) ? 0 :gdjs.Level2Code.GDShape4Objects3[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.Level2Code.GDShape4ExplosionObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDShape4ExplosionObjects3[i].setParticleSize1((( gdjs.Level2Code.GDShape4Objects3.length === 0 ) ? 0 :gdjs.Level2Code.GDShape4Objects3[0].getWidth()));
}
}
{ //Subevents
gdjs.Level2Code.eventsList2(runtimeScene);} //End of subevents
}

}


{


{
}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level2Code.GDScoreObjects3);
gdjs.copyArray(gdjs.Level2Code.GDShape1Objects2, gdjs.Level2Code.GDShape1Objects3);

gdjs.copyArray(gdjs.Level2Code.GDShape2Objects2, gdjs.Level2Code.GDShape2Objects3);

gdjs.copyArray(gdjs.Level2Code.GDShape3Objects2, gdjs.Level2Code.GDShape3Objects3);

gdjs.copyArray(gdjs.Level2Code.GDShape4Objects2, gdjs.Level2Code.GDShape4Objects3);

{for(var i = 0, len = gdjs.Level2Code.GDShape1Objects3.length ;i < len;++i) {
    gdjs.Level2Code.GDShape1Objects3[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level2Code.GDShape2Objects3.length ;i < len;++i) {
    gdjs.Level2Code.GDShape2Objects3[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level2Code.GDShape3Objects3.length ;i < len;++i) {
    gdjs.Level2Code.GDShape3Objects3[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level2Code.GDShape4Objects3.length ;i < len;++i) {
    gdjs.Level2Code.GDShape4Objects3[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "shoting1.mp3", false, 100, 1);
}{runtimeScene.getScene().getVariables().get("Score").add(1);
}{for(var i = 0, len = gdjs.Level2Code.GDScoreObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDScoreObjects3[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Score"))));
}
}}

}


};gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDObstacleObjects2Objects = Hashtable.newFrom({"Obstacle": gdjs.Level2Code.GDObstacleObjects2});
gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDEarthObjects2Objects = Hashtable.newFrom({"Earth": gdjs.Level2Code.GDEarthObjects2});
gdjs.Level2Code.eventsList4 = function(runtimeScene) {

};gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDObstacleObjects1Objects = Hashtable.newFrom({"Obstacle": gdjs.Level2Code.GDObstacleObjects1});
gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDButtonTryAgainObjects2Objects = Hashtable.newFrom({"ButtonTryAgain": gdjs.Level2Code.GDButtonTryAgainObjects2});
gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDButtonTryAgainObjects2Objects = Hashtable.newFrom({"ButtonTryAgain": gdjs.Level2Code.GDButtonTryAgainObjects2});
gdjs.Level2Code.eventsList5 = function(runtimeScene) {

{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
{gdjs.Level2Code.conditionTrue_1 = gdjs.Level2Code.condition0IsTrue_0;
gdjs.Level2Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16205940);
}
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.Level2Code.eventsList6 = function(runtimeScene) {

{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level2Code.GDButtonTryAgainObjects2, gdjs.Level2Code.GDButtonTryAgainObjects3);

{for(var i = 0, len = gdjs.Level2Code.GDButtonTryAgainObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDButtonTryAgainObjects3[i].setAnimationName("TryAgainPressed");
}
}
{ //Subevents
gdjs.Level2Code.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level2", false);
}}

}


};gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDButtonMainMenuObjects2Objects = Hashtable.newFrom({"ButtonMainMenu": gdjs.Level2Code.GDButtonMainMenuObjects2});
gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDButtonMainMenuObjects1Objects = Hashtable.newFrom({"ButtonMainMenu": gdjs.Level2Code.GDButtonMainMenuObjects1});
gdjs.Level2Code.eventsList7 = function(runtimeScene) {

{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
{gdjs.Level2Code.conditionTrue_1 = gdjs.Level2Code.condition0IsTrue_0;
gdjs.Level2Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16208380);
}
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.Level2Code.eventsList8 = function(runtimeScene) {

{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level2Code.GDButtonMainMenuObjects1, gdjs.Level2Code.GDButtonMainMenuObjects2);

{for(var i = 0, len = gdjs.Level2Code.GDButtonMainMenuObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDButtonMainMenuObjects2[i].setAnimationName("MainMenuPressed");
}
}
{ //Subevents
gdjs.Level2Code.eventsList7(runtimeScene);} //End of subevents
}

}


{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}

}


};gdjs.Level2Code.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level2Code.GDButtonTryAgainObjects1, gdjs.Level2Code.GDButtonTryAgainObjects2);


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDButtonTryAgainObjects2Objects, runtimeScene, true, true);
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level2Code.GDButtonTryAgainObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDButtonTryAgainObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDButtonTryAgainObjects2[i].setAnimationName("TryAgainNormal");
}
}}

}


{

gdjs.copyArray(gdjs.Level2Code.GDButtonTryAgainObjects1, gdjs.Level2Code.GDButtonTryAgainObjects2);


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDButtonTryAgainObjects2Objects, runtimeScene, true, false);
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level2Code.GDButtonTryAgainObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDButtonTryAgainObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDButtonTryAgainObjects2[i].setAnimationName("TryAgainHover");
}
}
{ //Subevents
gdjs.Level2Code.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Level2Code.GDButtonMainMenuObjects1, gdjs.Level2Code.GDButtonMainMenuObjects2);


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDButtonMainMenuObjects2Objects, runtimeScene, true, true);
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level2Code.GDButtonMainMenuObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDButtonMainMenuObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDButtonMainMenuObjects2[i].setAnimationName("MainMenuNormal");
}
}}

}


{

/* Reuse gdjs.Level2Code.GDButtonMainMenuObjects1 */

gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDButtonMainMenuObjects1Objects, runtimeScene, true, false);
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level2Code.GDButtonMainMenuObjects1 */
{for(var i = 0, len = gdjs.Level2Code.GDButtonMainMenuObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDButtonMainMenuObjects1[i].setAnimationName("MainMenuHover");
}
}
{ //Subevents
gdjs.Level2Code.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.Level2Code.GDbulletObjects1});
gdjs.Level2Code.eventsList10 = function(runtimeScene) {

{



}


{



}


{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "shoot-timer") > 0.25;
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("kenney"), gdjs.Level2Code.GDkenneyObjects1);
gdjs.Level2Code.GDbulletObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDbulletObjects1Objects, (( gdjs.Level2Code.GDkenneyObjects1.length === 0 ) ? 0 :gdjs.Level2Code.GDkenneyObjects1[0].getPointX("firespot")), (( gdjs.Level2Code.GDkenneyObjects1.length === 0 ) ? 0 :gdjs.Level2Code.GDkenneyObjects1[0].getPointY("firespot")), "");
}{for(var i = 0, len = gdjs.Level2Code.GDbulletObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDbulletObjects1[i].setAngle((( gdjs.Level2Code.GDkenneyObjects1.length === 0 ) ? 0 :gdjs.Level2Code.GDkenneyObjects1[0].getAngle()));
}
}{for(var i = 0, len = gdjs.Level2Code.GDbulletObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDbulletObjects1[i].addPolarForce((gdjs.Level2Code.GDbulletObjects1[i].getAngle()), 500, 1);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "shoot-timer");
}}

}


};gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDObstacleObjects2Objects = Hashtable.newFrom({"Obstacle": gdjs.Level2Code.GDObstacleObjects2});
gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDbulletObjects2Objects = Hashtable.newFrom({"bullet": gdjs.Level2Code.GDbulletObjects2});
gdjs.Level2Code.eventsList11 = function(runtimeScene) {

{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
{gdjs.Level2Code.conditionTrue_1 = gdjs.Level2Code.condition0IsTrue_0;
gdjs.Level2Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16217780);
}
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Bomb_blast1.mp3", false, 100, 1);
}}

}


};gdjs.Level2Code.eventsList12 = function(runtimeScene) {

};gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDPauseObjects1Objects = Hashtable.newFrom({"Pause": gdjs.Level2Code.GDPauseObjects1});
gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDPauseObjects1Objects = Hashtable.newFrom({"Pause": gdjs.Level2Code.GDPauseObjects1});
gdjs.Level2Code.eventsList13 = function(runtimeScene) {

{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
{gdjs.Level2Code.conditionTrue_1 = gdjs.Level2Code.condition0IsTrue_0;
gdjs.Level2Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16221396);
}
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.Level2Code.eventsList14 = function(runtimeScene) {

{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level2Code.GDPauseObjects1, gdjs.Level2Code.GDPauseObjects2);

{for(var i = 0, len = gdjs.Level2Code.GDPauseObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPauseObjects2[i].setAnimationName("StartPressed");
}
}
{ //Subevents
gdjs.Level2Code.eventsList13(runtimeScene);} //End of subevents
}

}


{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Pause_screen");
}}

}


};gdjs.Level2Code.eventsList15 = function(runtimeScene) {

};gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDMainmenu2Objects1Objects = Hashtable.newFrom({"Mainmenu2": gdjs.Level2Code.GDMainmenu2Objects1});
gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDMainmenu2Objects1Objects = Hashtable.newFrom({"Mainmenu2": gdjs.Level2Code.GDMainmenu2Objects1});
gdjs.Level2Code.eventsList16 = function(runtimeScene) {

{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
{gdjs.Level2Code.conditionTrue_1 = gdjs.Level2Code.condition0IsTrue_0;
gdjs.Level2Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16225004);
}
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "B1Sound.wav", false, 100, 1);
}}

}


};gdjs.Level2Code.eventsList17 = function(runtimeScene) {

{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level2Code.GDMainmenu2Objects1, gdjs.Level2Code.GDMainmenu2Objects2);

{for(var i = 0, len = gdjs.Level2Code.GDMainmenu2Objects2.length ;i < len;++i) {
    gdjs.Level2Code.GDMainmenu2Objects2[i].setAnimationName("StartPressed");
}
}
{ //Subevents
gdjs.Level2Code.eventsList16(runtimeScene);} //End of subevents
}

}


{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}

}


};gdjs.Level2Code.eventsList18 = function(runtimeScene) {

{


gdjs.Level2Code.eventsList0(runtimeScene);
}


{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
{gdjs.adMob.setupBanner("ca-app-pub-7829362827039995~7807956182", "", true);
}{gdjs.adMob.loadInterstitial("ca-app-pub-7829362827039995/8454274703", "", false);
}{gdjs.adMob.loadRewardedVideo("ca-app-pub-7829362827039995/9575784689", "", false);
}}

}


{


{
{gdjs.adMob.showBanner();
}}

}


{


{
}

}


{


{
}

}


{



}


{


{
}

}


{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1.3, "ShapeCreation");
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
gdjs.Level2Code.GDShape1Objects1.length = 0;

gdjs.Level2Code.GDShape2Objects1.length = 0;

gdjs.Level2Code.GDShape3Objects1.length = 0;

gdjs.Level2Code.GDShape4Objects1.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape1Objects1ObjectsGDgdjs_46Level2Code_46GDShape2Objects1ObjectsGDgdjs_46Level2Code_46GDShape3Objects1ObjectsGDgdjs_46Level2Code_46GDShape4Objects1Objects, "Shape" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 4)), gdjs.randomInRange(80, 640 - 80), 950, "");
}{for(var i = 0, len = gdjs.Level2Code.GDShape1Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape1Objects1[i].setAngle(gdjs.randomInRange(0, 0));
}
for(var i = 0, len = gdjs.Level2Code.GDShape2Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape2Objects1[i].setAngle(gdjs.randomInRange(0, 0));
}
for(var i = 0, len = gdjs.Level2Code.GDShape3Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape3Objects1[i].setAngle(gdjs.randomInRange(0, 0));
}
for(var i = 0, len = gdjs.Level2Code.GDShape4Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape4Objects1[i].setAngle(gdjs.randomInRange(0, 0));
}
}{for(var i = 0, len = gdjs.Level2Code.GDShape1Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape1Objects1[i].setScale(gdjs.randomFloatInRange(0.6, 0.6));
}
for(var i = 0, len = gdjs.Level2Code.GDShape2Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape2Objects1[i].setScale(gdjs.randomFloatInRange(0.6, 0.6));
}
for(var i = 0, len = gdjs.Level2Code.GDShape3Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape3Objects1[i].setScale(gdjs.randomFloatInRange(0.6, 0.6));
}
for(var i = 0, len = gdjs.Level2Code.GDShape4Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape4Objects1[i].setScale(gdjs.randomFloatInRange(0.6, 0.6));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ShapeCreation");
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Shape1"), gdjs.Level2Code.GDShape1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape2"), gdjs.Level2Code.GDShape2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape3"), gdjs.Level2Code.GDShape3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape4"), gdjs.Level2Code.GDShape4Objects1);
{for(var i = 0, len = gdjs.Level2Code.GDShape1Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape1Objects1[i].addPolarForce(270, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
for(var i = 0, len = gdjs.Level2Code.GDShape2Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape2Objects1[i].addPolarForce(270, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
for(var i = 0, len = gdjs.Level2Code.GDShape3Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape3Objects1[i].addPolarForce(270, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
for(var i = 0, len = gdjs.Level2Code.GDShape4Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape4Objects1[i].addPolarForce(270, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
}{for(var i = 0, len = gdjs.Level2Code.GDShape1Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape1Objects1[i].rotate(0, runtimeScene);
}
for(var i = 0, len = gdjs.Level2Code.GDShape2Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape2Objects1[i].rotate(0, runtimeScene);
}
for(var i = 0, len = gdjs.Level2Code.GDShape3Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape3Objects1[i].rotate(0, runtimeScene);
}
for(var i = 0, len = gdjs.Level2Code.GDShape4Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape4Objects1[i].rotate(0, runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Shape1"), gdjs.Level2Code.GDShape1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape2"), gdjs.Level2Code.GDShape2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape3"), gdjs.Level2Code.GDShape3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape4"), gdjs.Level2Code.GDShape4Objects1);

gdjs.Level2Code.forEachTotalCount2 = 0;
gdjs.Level2Code.forEachObjects2.length = 0;
gdjs.Level2Code.forEachCount0_2 = gdjs.Level2Code.GDShape1Objects1.length;
gdjs.Level2Code.forEachTotalCount2 += gdjs.Level2Code.forEachCount0_2;
gdjs.Level2Code.forEachObjects2.push.apply(gdjs.Level2Code.forEachObjects2,gdjs.Level2Code.GDShape1Objects1);
gdjs.Level2Code.forEachCount1_2 = gdjs.Level2Code.GDShape2Objects1.length;
gdjs.Level2Code.forEachTotalCount2 += gdjs.Level2Code.forEachCount1_2;
gdjs.Level2Code.forEachObjects2.push.apply(gdjs.Level2Code.forEachObjects2,gdjs.Level2Code.GDShape2Objects1);
gdjs.Level2Code.forEachCount2_2 = gdjs.Level2Code.GDShape3Objects1.length;
gdjs.Level2Code.forEachTotalCount2 += gdjs.Level2Code.forEachCount2_2;
gdjs.Level2Code.forEachObjects2.push.apply(gdjs.Level2Code.forEachObjects2,gdjs.Level2Code.GDShape3Objects1);
gdjs.Level2Code.forEachCount3_2 = gdjs.Level2Code.GDShape4Objects1.length;
gdjs.Level2Code.forEachTotalCount2 += gdjs.Level2Code.forEachCount3_2;
gdjs.Level2Code.forEachObjects2.push.apply(gdjs.Level2Code.forEachObjects2,gdjs.Level2Code.GDShape4Objects1);
for(gdjs.Level2Code.forEachIndex2 = 0;gdjs.Level2Code.forEachIndex2 < gdjs.Level2Code.forEachTotalCount2;++gdjs.Level2Code.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.Level2Code.GDbulletObjects2);
gdjs.Level2Code.GDShape1Objects2.length = 0;

gdjs.Level2Code.GDShape2Objects2.length = 0;

gdjs.Level2Code.GDShape3Objects2.length = 0;

gdjs.Level2Code.GDShape4Objects2.length = 0;


if (gdjs.Level2Code.forEachIndex2 < gdjs.Level2Code.forEachCount0_2) {
    gdjs.Level2Code.GDShape1Objects2.push(gdjs.Level2Code.forEachObjects2[gdjs.Level2Code.forEachIndex2]);
}
else if (gdjs.Level2Code.forEachIndex2 < gdjs.Level2Code.forEachCount0_2+gdjs.Level2Code.forEachCount1_2) {
    gdjs.Level2Code.GDShape2Objects2.push(gdjs.Level2Code.forEachObjects2[gdjs.Level2Code.forEachIndex2]);
}
else if (gdjs.Level2Code.forEachIndex2 < gdjs.Level2Code.forEachCount0_2+gdjs.Level2Code.forEachCount1_2+gdjs.Level2Code.forEachCount2_2) {
    gdjs.Level2Code.GDShape3Objects2.push(gdjs.Level2Code.forEachObjects2[gdjs.Level2Code.forEachIndex2]);
}
else if (gdjs.Level2Code.forEachIndex2 < gdjs.Level2Code.forEachCount0_2+gdjs.Level2Code.forEachCount1_2+gdjs.Level2Code.forEachCount2_2+gdjs.Level2Code.forEachCount3_2) {
    gdjs.Level2Code.GDShape4Objects2.push(gdjs.Level2Code.forEachObjects2[gdjs.Level2Code.forEachIndex2]);
}
gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDShape1Objects2ObjectsGDgdjs_46Level2Code_46GDShape2Objects2ObjectsGDgdjs_46Level2Code_46GDShape3Objects2ObjectsGDgdjs_46Level2Code_46GDShape4Objects2Objects, gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDbulletObjects2Objects, false, runtimeScene, false);
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.Level2Code.GDbulletObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDbulletObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents: 
gdjs.Level2Code.eventsList3(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Obstacle"), gdjs.Level2Code.GDObstacleObjects1);

for(gdjs.Level2Code.forEachIndex2 = 0;gdjs.Level2Code.forEachIndex2 < gdjs.Level2Code.GDObstacleObjects1.length;++gdjs.Level2Code.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("Earth"), gdjs.Level2Code.GDEarthObjects2);
gdjs.Level2Code.GDObstacleObjects2.length = 0;


gdjs.Level2Code.forEachTemporary2 = gdjs.Level2Code.GDObstacleObjects1[gdjs.Level2Code.forEachIndex2];
gdjs.Level2Code.GDObstacleObjects2.push(gdjs.Level2Code.forEachTemporary2);
gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDObstacleObjects2Objects, gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDEarthObjects2Objects, false, runtimeScene, false);
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.Level2Code.GDObstacleObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDObstacleObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level2Code.GDEarthObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDEarthObjects2[i].getBehavior("Health").Hit(1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Bomb_blast1.mp3", false, 100, 1);
}}
}

}


{



}


{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 5, "ObstacleCreation");
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
gdjs.Level2Code.GDObstacleObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDObstacleObjects1Objects, gdjs.randomInRange(80, 640 - 80), 950, "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ObstacleCreation");
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Obstacle"), gdjs.Level2Code.GDObstacleObjects1);
{for(var i = 0, len = gdjs.Level2Code.GDObstacleObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDObstacleObjects1[i].addPolarForce(270, 1.5 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
}{for(var i = 0, len = gdjs.Level2Code.GDObstacleObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDObstacleObjects1[i].setZOrder(4);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Earth"), gdjs.Level2Code.GDEarthObjects1);

gdjs.Level2Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level2Code.GDEarthObjects1.length;i<l;++i) {
    if ( gdjs.Level2Code.GDEarthObjects1[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level2Code.condition0IsTrue_0.val = true;
        gdjs.Level2Code.GDEarthObjects1[k] = gdjs.Level2Code.GDEarthObjects1[i];
        ++k;
    }
}
gdjs.Level2Code.GDEarthObjects1.length = k;}if (gdjs.Level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level2Code.GDEarthObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Life"), gdjs.Level2Code.GDLifeObjects1);
{for(var i = 0, len = gdjs.Level2Code.GDLifeObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDLifeObjects1[i].setAnimationName("Life" + gdjs.evtTools.common.toString((( gdjs.Level2Code.GDEarthObjects1.length === 0 ) ? 0 :gdjs.Level2Code.GDEarthObjects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))));
}
}{for(var i = 0, len = gdjs.Level2Code.GDEarthObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDEarthObjects1[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Earth"), gdjs.Level2Code.GDEarthObjects1);

gdjs.Level2Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level2Code.GDEarthObjects1.length;i<l;++i) {
    if ( gdjs.Level2Code.GDEarthObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level2Code.condition0IsTrue_0.val = true;
        gdjs.Level2Code.GDEarthObjects1[k] = gdjs.Level2Code.GDEarthObjects1[i];
        ++k;
    }
}
gdjs.Level2Code.GDEarthObjects1.length = k;}if (gdjs.Level2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ButtonMainMenu"), gdjs.Level2Code.GDButtonMainMenuObjects1);
gdjs.copyArray(runtimeScene.getObjects("ButtonTryAgain"), gdjs.Level2Code.GDButtonTryAgainObjects1);
/* Reuse gdjs.Level2Code.GDEarthObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Gameover"), gdjs.Level2Code.GDGameoverObjects1);
gdjs.copyArray(runtimeScene.getObjects("Life"), gdjs.Level2Code.GDLifeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Obstacle"), gdjs.Level2Code.GDObstacleObjects1);
gdjs.copyArray(runtimeScene.getObjects("Shape1"), gdjs.Level2Code.GDShape1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape2"), gdjs.Level2Code.GDShape2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape3"), gdjs.Level2Code.GDShape3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shape4"), gdjs.Level2Code.GDShape4Objects1);
{for(var i = 0, len = gdjs.Level2Code.GDLifeObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDLifeObjects1[i].setAnimationName("Life0");
}
}{for(var i = 0, len = gdjs.Level2Code.GDEarthObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDEarthObjects1[i].setAnimationName("MonsterDead");
}
}{for(var i = 0, len = gdjs.Level2Code.GDShape1Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape1Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level2Code.GDShape2Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape2Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level2Code.GDShape3Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape3Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level2Code.GDShape4Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDShape4Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level2Code.GDObstacleObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDObstacleObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level2Code.GDGameoverObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDGameoverObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level2Code.GDButtonTryAgainObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDButtonTryAgainObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level2Code.GDButtonMainMenuObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDButtonMainMenuObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.Level2Code.eventsList9(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ButtonMainMenu"), gdjs.Level2Code.GDButtonMainMenuObjects1);
gdjs.copyArray(runtimeScene.getObjects("ButtonTryAgain"), gdjs.Level2Code.GDButtonTryAgainObjects1);
gdjs.copyArray(runtimeScene.getObjects("Gameover"), gdjs.Level2Code.GDGameoverObjects1);
{for(var i = 0, len = gdjs.Level2Code.GDGameoverObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDGameoverObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level2Code.GDButtonTryAgainObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDButtonTryAgainObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level2Code.GDButtonMainMenuObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDButtonMainMenuObjects1[i].hide();
}
}}

}


{



}


{


{
{runtimeScene.getScene().getVariables().getFromIndex(0).add(7 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}}

}


{


{
}

}


{


{
}

}


{



}


{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "shoot-timer");
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("kenney"), gdjs.Level2Code.GDkenneyObjects1);
{for(var i = 0, len = gdjs.Level2Code.GDkenneyObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDkenneyObjects1[i].rotateTowardPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 0, runtimeScene);
}
}}

}


{


gdjs.Level2Code.condition0IsTrue_0.val = false;
{
{gdjs.Level2Code.conditionTrue_1 = gdjs.Level2Code.condition0IsTrue_0;
gdjs.Level2Code.condition0IsTrue_1.val = false;
gdjs.Level2Code.condition1IsTrue_1.val = false;
{
gdjs.Level2Code.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if( gdjs.Level2Code.condition0IsTrue_1.val ) {
    gdjs.Level2Code.conditionTrue_1.val = true;
}
}
{
gdjs.Level2Code.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if( gdjs.Level2Code.condition1IsTrue_1.val ) {
    gdjs.Level2Code.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.Level2Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level2Code.eventsList10(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Obstacle"), gdjs.Level2Code.GDObstacleObjects1);

for(gdjs.Level2Code.forEachIndex2 = 0;gdjs.Level2Code.forEachIndex2 < gdjs.Level2Code.GDObstacleObjects1.length;++gdjs.Level2Code.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.Level2Code.GDbulletObjects2);
gdjs.Level2Code.GDObstacleObjects2.length = 0;


gdjs.Level2Code.forEachTemporary2 = gdjs.Level2Code.GDObstacleObjects1[gdjs.Level2Code.forEachIndex2];
gdjs.Level2Code.GDObstacleObjects2.push(gdjs.Level2Code.forEachTemporary2);
gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDObstacleObjects2Objects, gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDbulletObjects2Objects, false, runtimeScene, false);
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.Level2Code.GDbulletObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDbulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level2Code.GDObstacleObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDObstacleObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents: 
gdjs.Level2Code.eventsList11(runtimeScene);} //Subevents end.
}
}

}


{


{
}

}


{


{
}

}


{


gdjs.Level2Code.eventsList12(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Pause"), gdjs.Level2Code.GDPauseObjects1);

gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDPauseObjects1Objects, runtimeScene, true, true);
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level2Code.GDPauseObjects1 */
{for(var i = 0, len = gdjs.Level2Code.GDPauseObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPauseObjects1[i].setAnimationName("StartNormal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Pause"), gdjs.Level2Code.GDPauseObjects1);

gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDPauseObjects1Objects, runtimeScene, true, false);
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level2Code.GDPauseObjects1 */
{for(var i = 0, len = gdjs.Level2Code.GDPauseObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPauseObjects1[i].setAnimationName("StartHover");
}
}
{ //Subevents
gdjs.Level2Code.eventsList14(runtimeScene);} //End of subevents
}

}


{


{
}

}


{


gdjs.Level2Code.eventsList15(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Mainmenu2"), gdjs.Level2Code.GDMainmenu2Objects1);

gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDMainmenu2Objects1Objects, runtimeScene, true, true);
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level2Code.GDMainmenu2Objects1 */
{for(var i = 0, len = gdjs.Level2Code.GDMainmenu2Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDMainmenu2Objects1[i].setAnimationName("StartNormal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mainmenu2"), gdjs.Level2Code.GDMainmenu2Objects1);

gdjs.Level2Code.condition0IsTrue_0.val = false;
{
gdjs.Level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level2Code.mapOfGDgdjs_46Level2Code_46GDMainmenu2Objects1Objects, runtimeScene, true, false);
}if (gdjs.Level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level2Code.GDMainmenu2Objects1 */
{for(var i = 0, len = gdjs.Level2Code.GDMainmenu2Objects1.length ;i < len;++i) {
    gdjs.Level2Code.GDMainmenu2Objects1[i].setAnimationName("StartHover");
}
}
{ //Subevents
gdjs.Level2Code.eventsList17(runtimeScene);} //End of subevents
}

}


{


{
}

}


};

gdjs.Level2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level2Code.GDEarthObjects1.length = 0;
gdjs.Level2Code.GDEarthObjects2.length = 0;
gdjs.Level2Code.GDEarthObjects3.length = 0;
gdjs.Level2Code.GDEarthObjects4.length = 0;
gdjs.Level2Code.GDPauseObjects1.length = 0;
gdjs.Level2Code.GDPauseObjects2.length = 0;
gdjs.Level2Code.GDPauseObjects3.length = 0;
gdjs.Level2Code.GDPauseObjects4.length = 0;
gdjs.Level2Code.GDkenneyObjects1.length = 0;
gdjs.Level2Code.GDkenneyObjects2.length = 0;
gdjs.Level2Code.GDkenneyObjects3.length = 0;
gdjs.Level2Code.GDkenneyObjects4.length = 0;
gdjs.Level2Code.GDbulletObjects1.length = 0;
gdjs.Level2Code.GDbulletObjects2.length = 0;
gdjs.Level2Code.GDbulletObjects3.length = 0;
gdjs.Level2Code.GDbulletObjects4.length = 0;
gdjs.Level2Code.GDShape1Objects1.length = 0;
gdjs.Level2Code.GDShape1Objects2.length = 0;
gdjs.Level2Code.GDShape1Objects3.length = 0;
gdjs.Level2Code.GDShape1Objects4.length = 0;
gdjs.Level2Code.GDShape2Objects1.length = 0;
gdjs.Level2Code.GDShape2Objects2.length = 0;
gdjs.Level2Code.GDShape2Objects3.length = 0;
gdjs.Level2Code.GDShape2Objects4.length = 0;
gdjs.Level2Code.GDShape3Objects1.length = 0;
gdjs.Level2Code.GDShape3Objects2.length = 0;
gdjs.Level2Code.GDShape3Objects3.length = 0;
gdjs.Level2Code.GDShape3Objects4.length = 0;
gdjs.Level2Code.GDShape4Objects1.length = 0;
gdjs.Level2Code.GDShape4Objects2.length = 0;
gdjs.Level2Code.GDShape4Objects3.length = 0;
gdjs.Level2Code.GDShape4Objects4.length = 0;
gdjs.Level2Code.GDScoreObjects1.length = 0;
gdjs.Level2Code.GDScoreObjects2.length = 0;
gdjs.Level2Code.GDScoreObjects3.length = 0;
gdjs.Level2Code.GDScoreObjects4.length = 0;
gdjs.Level2Code.GDObstacleObjects1.length = 0;
gdjs.Level2Code.GDObstacleObjects2.length = 0;
gdjs.Level2Code.GDObstacleObjects3.length = 0;
gdjs.Level2Code.GDObstacleObjects4.length = 0;
gdjs.Level2Code.GDLifeObjects1.length = 0;
gdjs.Level2Code.GDLifeObjects2.length = 0;
gdjs.Level2Code.GDLifeObjects3.length = 0;
gdjs.Level2Code.GDLifeObjects4.length = 0;
gdjs.Level2Code.GDButtonTryAgainObjects1.length = 0;
gdjs.Level2Code.GDButtonTryAgainObjects2.length = 0;
gdjs.Level2Code.GDButtonTryAgainObjects3.length = 0;
gdjs.Level2Code.GDButtonTryAgainObjects4.length = 0;
gdjs.Level2Code.GDButtonMainMenuObjects1.length = 0;
gdjs.Level2Code.GDButtonMainMenuObjects2.length = 0;
gdjs.Level2Code.GDButtonMainMenuObjects3.length = 0;
gdjs.Level2Code.GDButtonMainMenuObjects4.length = 0;
gdjs.Level2Code.GDShape4ExplosionObjects1.length = 0;
gdjs.Level2Code.GDShape4ExplosionObjects2.length = 0;
gdjs.Level2Code.GDShape4ExplosionObjects3.length = 0;
gdjs.Level2Code.GDShape4ExplosionObjects4.length = 0;
gdjs.Level2Code.GDShape3ExplosionObjects1.length = 0;
gdjs.Level2Code.GDShape3ExplosionObjects2.length = 0;
gdjs.Level2Code.GDShape3ExplosionObjects3.length = 0;
gdjs.Level2Code.GDShape3ExplosionObjects4.length = 0;
gdjs.Level2Code.GDShape2ExplosionObjects1.length = 0;
gdjs.Level2Code.GDShape2ExplosionObjects2.length = 0;
gdjs.Level2Code.GDShape2ExplosionObjects3.length = 0;
gdjs.Level2Code.GDShape2ExplosionObjects4.length = 0;
gdjs.Level2Code.GDShape1ExplosionObjects1.length = 0;
gdjs.Level2Code.GDShape1ExplosionObjects2.length = 0;
gdjs.Level2Code.GDShape1ExplosionObjects3.length = 0;
gdjs.Level2Code.GDShape1ExplosionObjects4.length = 0;
gdjs.Level2Code.GDEarth1Objects1.length = 0;
gdjs.Level2Code.GDEarth1Objects2.length = 0;
gdjs.Level2Code.GDEarth1Objects3.length = 0;
gdjs.Level2Code.GDEarth1Objects4.length = 0;
gdjs.Level2Code.GDLifetextObjects1.length = 0;
gdjs.Level2Code.GDLifetextObjects2.length = 0;
gdjs.Level2Code.GDLifetextObjects3.length = 0;
gdjs.Level2Code.GDLifetextObjects4.length = 0;
gdjs.Level2Code.GDRed1Objects1.length = 0;
gdjs.Level2Code.GDRed1Objects2.length = 0;
gdjs.Level2Code.GDRed1Objects3.length = 0;
gdjs.Level2Code.GDRed1Objects4.length = 0;
gdjs.Level2Code.GDMainmenu2Objects1.length = 0;
gdjs.Level2Code.GDMainmenu2Objects2.length = 0;
gdjs.Level2Code.GDMainmenu2Objects3.length = 0;
gdjs.Level2Code.GDMainmenu2Objects4.length = 0;
gdjs.Level2Code.GDGameoverObjects1.length = 0;
gdjs.Level2Code.GDGameoverObjects2.length = 0;
gdjs.Level2Code.GDGameoverObjects3.length = 0;
gdjs.Level2Code.GDGameoverObjects4.length = 0;
gdjs.Level2Code.GDBlack1Objects1.length = 0;
gdjs.Level2Code.GDBlack1Objects2.length = 0;
gdjs.Level2Code.GDBlack1Objects3.length = 0;
gdjs.Level2Code.GDBlack1Objects4.length = 0;
gdjs.Level2Code.GDScreen_95borderObjects1.length = 0;
gdjs.Level2Code.GDScreen_95borderObjects2.length = 0;
gdjs.Level2Code.GDScreen_95borderObjects3.length = 0;
gdjs.Level2Code.GDScreen_95borderObjects4.length = 0;
gdjs.Level2Code.GDBGS1Objects1.length = 0;
gdjs.Level2Code.GDBGS1Objects2.length = 0;
gdjs.Level2Code.GDBGS1Objects3.length = 0;
gdjs.Level2Code.GDBGS1Objects4.length = 0;

gdjs.Level2Code.eventsList18(runtimeScene);

return;

}

gdjs['Level2Code'] = gdjs.Level2Code;
